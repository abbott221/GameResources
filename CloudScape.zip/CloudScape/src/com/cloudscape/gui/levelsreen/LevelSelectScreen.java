package com.cloudscape.gui.levelsreen;

import java.util.LinkedList;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.SelectBox;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextArea;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.scenes.scene2d.ui.TextField.TextFieldListener;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener.ChangeEvent;
import com.cloudscape.DeviceScreen;
import com.cloudscape.gui.GameClass;
import com.cloudscape.gui.MainScreen;
import com.cloudscape.gui.creatorscreen.MapCreatorScreen;
import com.cloudscape.gui.gamescreen.GamePlayScreen;
import com.cloudscape.gui.widgets.MainMenuButton;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.actors.Grue;
import com.cloudscape.objects.actors.Knight;
import com.cloudscape.objects.actors.aliens.BeigeAlien;
import com.cloudscape.objects.actors.aliens.BlueAlien;
import com.cloudscape.objects.levels.Level;
import com.cloudscape.objects.levels.Level1;
import com.cloudscape.objects.levels.Level2;
import com.cloudscape.objects.levels.Level3;
import com.cloudscape.objects.levels.Level4;
import com.cloudscape.objects.levels.PlayerVnpcLevel;
import com.cloudscape.objects.levels.StoredLevel1Player;
import com.cloudscape.objects.levels.StoredLevel2Player;
import com.cloudscape.objects.levels.StoredLevelNPCs;
import com.cloudscape.objects.players.NPC;
import com.cloudscape.objects.players.Player;

public class LevelSelectScreen implements Screen {
	
	private final class LevelButtonListener extends ChangeListener {
		Level myLevel;
		LevelButtonListener(Level level) {
			myLevel = level;
		}
		@Override
		public void changed(ChangeEvent event, Actor actor) {
			GameClass.getInstance().setScreen(new GamePlayScreen(myLevel));
		}
	}
	
	Stage stage;
	Skin skin;
	
	private static String importMapName = "Map Name";
	
	
	
	
	
	private final static int LVL_PANEL_LEFT_MARGIN = 50;
	private final static int LVL_PANEL_BOTTOM_MARGIN = 50;
	
	//private final static int LVL_PANEL_Y_SPACING = (int) (50 * DeviceScreen.buttonScale);
	private final static int LVL_PANEL_Y_SPACING = (int) (30 * DeviceScreen.buttonScale);
	//private final static int LVL_PANEL_X_SPACING = (int) (150 * DeviceScreen.buttonScale);
	private final static int LVL_PANEL_X_SPACING = (int) (120 * DeviceScreen.buttonScale);
	
	private final static int LVL_PANEL_BTN_WIDTH = (int) (100 * DeviceScreen.buttonScale);
	private final static int LVL_PANEL_BTN_HEIGHT = (int) (20 * DeviceScreen.buttonScale);
	
	
	
	
	
	private final static int CREATOR_RIGHT_MARGIN = 50;
	private final static int CREATOR_PANEL_WIDTH = (int) (200 * DeviceScreen.buttonScale);
	private final static int CREATOR_LEFT_MARGIN = Gdx.graphics.getWidth() - (CREATOR_PANEL_WIDTH + CREATOR_RIGHT_MARGIN);
	
	private final static int CREATOR_BTN_HEIGHT = (int) (20 * DeviceScreen.buttonScale);
	//width for the large buttons
	private final static int CREATOR_L_BTN_WIDTH = (int) (180 * DeviceScreen.buttonScale);
	//width for the small buttons
	private final static int CREATOR_S_BTN_WIDTH = (int) (150 * DeviceScreen.buttonScale);
	private final static int CREATOR_BTN_INDENT = (int) (30 * DeviceScreen.buttonScale);
	private final static int CREATOR_BTN_Y_SPACING = (int) (30 * DeviceScreen.buttonScale); //ALSO USES A SPACING OF 30
	
	//the bottom margin is only used for calculating the top margin
	private final static int CREATOR_BOTTOM_MARGIN = 50;
	private final static int CREATOR_TOP_MARGIN = CREATOR_BOTTOM_MARGIN + 7*CREATOR_BTN_Y_SPACING;
	//private final static int CREATOR_TOP_MARGIN = Gdx.graphics.getHeight() - (50 + CREATOR_BTN_HEIGHT);
	
	
	
	
	public LevelSelectScreen() {
		makeItFit();
	}
	
	@Override
	public void resize(int width, int height) {
		makeItFit();
	}
	
	@Override
	public void render(float arg0) {
		Gdx.gl.glClearColor(0.2f, 0.2f, 0.2f, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
		stage.draw();
	}
	
	private void makeItFit() {
		stage = new Stage();
		Gdx.input.setInputProcessor(stage);
		skin = new Skin(Gdx.files.internal("data/uiskin.json"));
		
		
		
		
		addUsernamePanel(stage, skin);
		
		
		
		
		
		
		for (int i = 0; i < 12; i++) {
			String lvlString = Integer.toString(i + 1);
			if (i + 1 < 10) {
				lvlString = "0" + lvlString;
			}
			
			TextButton currentBtn = new TextButton("Level " + Integer.toString(i + 1), skin);
			
			int r = i % 5;
			int c = i / 5;
			
			currentBtn.setBounds(LVL_PANEL_LEFT_MARGIN + c*LVL_PANEL_X_SPACING,
					LVL_PANEL_BOTTOM_MARGIN + (5-r)*LVL_PANEL_Y_SPACING,
					LVL_PANEL_BTN_WIDTH, LVL_PANEL_BTN_HEIGHT);
			
			stage.addActor(currentBtn);
			currentBtn.addListener(new LevelButtonListener(new PlayerVnpcLevel("levels/level" + lvlString + ".xml")));
		}
		
		
		
		
		
		//=======
		
		addCreatorPanel(stage, skin);
		
		
		
		//http://stackoverflow.com/questions/23809849/why-is-my-libgdx-scrollpane-not-scrolling-horizontally
		//http://www.java-gaming.org/index.php?topic=29201.0
		//https://github.com/libgdx/libgdx/blob/master/tests/gdx-tests/src/com/badlogic/gdx/tests/ScrollPaneTest.java
		
		//SUCCESSFULLY GETS VERTICAL, LEAVES HORIZONTAL, LEAVES NO GAPS ON SIDES OF SCROLLPANE
		
//		Table inner = new Table();
//		
//		ScrollPane pane = new ScrollPane(inner, skin);
//		pane.setSize(400, 100);
//		
//		TextArea xmlArea = new TextArea("aaaaa \n bbbbb \n ccccc \n ddddd \n eeeee \n ffff", skin);
//		inner.add(xmlArea).minHeight(500).fill().expand();
//		
//		//Table outer = new Table();
//		//outer.add(pane).fill().expand();
//		//outer.add(pane).fill(false);
//		
//		//stage.addActor(outer);
//		stage.addActor(pane);
		
		
		
		//stage.addActor(new MainMenuButton(skin));
		addMainMenuButton(stage, skin);
	}
	
	
	private static void addUsernamePanel(final Stage stage, final Skin skin) {
		Label userLabel = new Label("Username:", skin);
		//LVL_PANEL_BOTTOM_MARGIN
		//userLabel.setBounds(LVL_PANEL_LEFT_MARGIN, 350, 100, 20);
		userLabel.setBounds(LVL_PANEL_LEFT_MARGIN, LVL_PANEL_BOTTOM_MARGIN + LVL_PANEL_Y_SPACING * 7,
				100 * DeviceScreen.buttonScale, 20 * DeviceScreen.buttonScale);
		stage.addActor(userLabel);
		
		//userLabel.setFontScale(DeviceScreen.buttonScale, DeviceScreen.buttonScale);
		
		
		TextField userField = new TextField(GameClass.getInstance().username, skin);
		//userField.setBounds(180, 350,
		userField.setBounds(LVL_PANEL_LEFT_MARGIN + 100 * DeviceScreen.buttonScale, LVL_PANEL_BOTTOM_MARGIN + LVL_PANEL_Y_SPACING * 7,
				100 * DeviceScreen.buttonScale, 20 * DeviceScreen.buttonScale);
		stage.addActor(userField);
		userField.setTextFieldListener(new TextFieldListener() {
			@Override
			public void keyTyped(TextField textField, char key) {
				if (key == '\r' || key == '\n') {
					textField.getOnscreenKeyboard().show(false);
					stage.setKeyboardFocus(null);
					GameClass.getInstance().username = textField.getText();
				}
				
				GameClass.getInstance().username = textField.getText();
			}
		});
	}
	
	
	private static void addCreatorPanel(final Stage stage, final Skin skin) {
		TextButton mapScreen = new TextButton("Create New Map", skin);
		//mapScreen.setBounds(COLUMN_ONE_X_START, COLUMN_ONE_Y_START, 180, 20);
		mapScreen.setBounds(CREATOR_LEFT_MARGIN, CREATOR_TOP_MARGIN, CREATOR_L_BTN_WIDTH, CREATOR_BTN_HEIGHT);
		stage.addActor(mapScreen);
		mapScreen.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new MapCreatorScreen());
			}
		});
		
		
		//CREATOR_TOP_MARGIN
		
		
		final SelectBox levelDropDown = new SelectBox(skin);
		levelDropDown.setItems(GameClass.getInstance().savedMaps.keySet().toArray());
		//levelDropDown.setBounds(290, 50, 180, 20);
		//levelDropDown.setBounds(CREATOR_LEFT_MARGIN, DROP_DOWN_Y_START, CREATOR_L_BTN_WIDTH, CREATOR_BTN_HEIGHT); //*4 on spacing
		levelDropDown.setBounds(CREATOR_LEFT_MARGIN, CREATOR_TOP_MARGIN - 2*CREATOR_BTN_Y_SPACING, CREATOR_L_BTN_WIDTH, CREATOR_BTN_HEIGHT);
		stage.addActor(levelDropDown);
		
		TextButton importButton = new TextButton("Import XML", skin);
		//mapScreen.setBounds(COLUMN_ONE_X_START, COLUMN_ONE_Y_START, 180, 20);
		importButton.setBounds(CREATOR_LEFT_MARGIN, CREATOR_TOP_MARGIN - 1*CREATOR_BTN_Y_SPACING, CREATOR_L_BTN_WIDTH, CREATOR_BTN_HEIGHT);
		stage.addActor(importButton);
		importButton.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				
				Table inner = new Table();
				
				ScrollPane pane = new ScrollPane(inner, skin);
				pane.setSize(400, 100);
				
				final TextArea xmlArea = new TextArea("paste xml here", skin);
				inner.add(xmlArea).minHeight(500).fill().expand();
				
				final Window window = new Window("Dialog", skin);
				
				TextField mapNameField = new TextField(importMapName, skin);
				mapNameField.setTextFieldListener(new TextFieldListener() {
					@Override
					public void keyTyped(TextField textField, char key) {
						if (key == '\r' || key == '\n') {
							textField.getOnscreenKeyboard().show(false);
							stage.setKeyboardFocus(null);
							importMapName = textField.getText();
						}
						
						importMapName = textField.getText();
					}
				});
				window.add(mapNameField);
				window.row();
				
				window.add(pane).fill().expand();
				window.setPosition(100, 100);
				window.setSize(400, 200);
				stage.addActor(window);
				
				window.row();
				
				TextButton importText = new TextButton("Import", skin);
				importText.addListener(new ChangeListener() {
					@Override
					public void changed(ChangeEvent event, Actor actor) {
						System.out.println(xmlArea.getText());
						GameClass.getInstance().savedMaps.put(importMapName, xmlArea.getText());
						window.remove();
						levelDropDown.setItems(GameClass.getInstance().savedMaps.keySet().toArray());
					}
				});
				window.add(importText);
				
				window.row();
				
				TextButton close = new TextButton("Close", skin);
				close.addListener(new ChangeListener() {
					@Override
					public void changed(ChangeEvent event, Actor actor) {
						window.remove();
					}
				});
				window.add(close);
				
			}
		});
		
		
		TextButton singlePlayer = new TextButton("Play (1 Player)", skin);
		//singlePlayer.setBounds(490, 50, 180, 20);
		//singlePlayer.setBounds(CREATOR_LEFT_MARGIN + CREATOR_BTN_INDENT, DROP_DOWN_Y_START - 30, CREATOR_S_BTN_WIDTH, CREATOR_BTN_HEIGHT);
		singlePlayer.setBounds(CREATOR_LEFT_MARGIN + CREATOR_BTN_INDENT, CREATOR_TOP_MARGIN - 3*CREATOR_BTN_Y_SPACING, CREATOR_S_BTN_WIDTH, CREATOR_BTN_HEIGHT);
		stage.addActor(singlePlayer);
		singlePlayer.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new GamePlayScreen(new StoredLevel1Player(
						GameClass.getInstance().savedMaps.get(levelDropDown.getSelected().toString())
						)));
			}
		});
		
		TextButton twoPlayer = new TextButton("Play (2 Player)", skin);
		//twoPlayer.setBounds(690, 50, 180, 20);
		//twoPlayer.setBounds(CREATOR_LEFT_MARGIN + CREATOR_BTN_INDENT, DROP_DOWN_Y_START - 60, CREATOR_S_BTN_WIDTH, CREATOR_BTN_HEIGHT);
		twoPlayer.setBounds(CREATOR_LEFT_MARGIN + CREATOR_BTN_INDENT, CREATOR_TOP_MARGIN - 4*CREATOR_BTN_Y_SPACING, CREATOR_S_BTN_WIDTH, CREATOR_BTN_HEIGHT);
		stage.addActor(twoPlayer);
		twoPlayer.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new GamePlayScreen(new StoredLevel2Player(
						GameClass.getInstance().savedMaps.get(levelDropDown.getSelected().toString())
						)));
			}
		});
		
		TextButton npcGame = new TextButton("NPC vs. NPC", skin);
		//twoPlayer.setBounds(690, 50, 180, 20);
		//npcGame.setBounds(CREATOR_LEFT_MARGIN + CREATOR_BTN_INDENT, DROP_DOWN_Y_START - 90, CREATOR_S_BTN_WIDTH, CREATOR_BTN_HEIGHT);
		npcGame.setBounds(CREATOR_LEFT_MARGIN + CREATOR_BTN_INDENT, CREATOR_TOP_MARGIN - 5*CREATOR_BTN_Y_SPACING, CREATOR_S_BTN_WIDTH, CREATOR_BTN_HEIGHT);
		stage.addActor(npcGame);
		npcGame.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new GamePlayScreen(new StoredLevelNPCs(
						GameClass.getInstance().savedMaps.get(levelDropDown.getSelected().toString())
						)));
			}
		});
		
		TextButton displayXML = new TextButton("Display XML", skin);
		//twoPlayer.setBounds(690, 50, 180, 20);
		//displayXML.setBounds(CREATOR_LEFT_MARGIN + CREATOR_BTN_INDENT, DROP_DOWN_Y_START - 120, CREATOR_S_BTN_WIDTH, CREATOR_BTN_HEIGHT);
		displayXML.setBounds(CREATOR_LEFT_MARGIN + CREATOR_BTN_INDENT, CREATOR_TOP_MARGIN - 6*CREATOR_BTN_Y_SPACING, CREATOR_S_BTN_WIDTH, CREATOR_BTN_HEIGHT);
		stage.addActor(displayXML);
		displayXML.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				
				String xml = GameClass.getInstance().savedMaps.get(levelDropDown.getSelected().toString());
				
				//=======
				
				Table inner = new Table();
				
				ScrollPane pane = new ScrollPane(inner, skin);
				pane.setSize(400, 100);
				
				TextArea xmlArea = new TextArea(xml, skin);
				inner.add(xmlArea).minHeight(500).fill().expand();
				
				final Window window = new Window("Dialog", skin);
				window.add(pane).fill().expand();
				window.setPosition(100, 100);
				window.setSize(400, 200);
				stage.addActor(window);
				
				window.row();
				TextButton close = new TextButton("Close", skin);
				close.addListener(new ChangeListener() {
					@Override
					public void changed(ChangeEvent event, Actor actor) {
						window.remove();
					}
				});
				window.add(close);
				
			}
		});
		
		TextButton modifyButton = new TextButton("Modify Map", skin);
		//mapScreen.setBounds(COLUMN_ONE_X_START, COLUMN_ONE_Y_START, 180, 20);
		//modifyButton.setBounds(CREATOR_LEFT_MARGIN + CREATOR_BTN_INDENT, DROP_DOWN_Y_START - 150, CREATOR_S_BTN_WIDTH, CREATOR_BTN_HEIGHT);
		modifyButton.setBounds(CREATOR_LEFT_MARGIN + CREATOR_BTN_INDENT, CREATOR_TOP_MARGIN - 7*CREATOR_BTN_Y_SPACING, CREATOR_S_BTN_WIDTH, CREATOR_BTN_HEIGHT);
		stage.addActor(modifyButton);
		modifyButton.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				String mapName = levelDropDown.getSelected().toString();
				
				String xml = GameClass.getInstance().savedMaps.get(mapName);
				
				GameClass.getInstance().setScreen(new MapCreatorScreen(mapName, xml));
			}
		});
	}
	
	
	private static void addMainMenuButton(Stage stage, Skin skin) {
		int top = Gdx.graphics.getHeight();
		
		TextButton returnButton = new TextButton("Main Menu", skin);
		returnButton.setBounds(20, top - (20 + 20 * DeviceScreen.buttonScale), 180 * DeviceScreen.buttonScale, 20 * DeviceScreen.buttonScale);
		stage.addActor(returnButton);
		returnButton.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new MainScreen());
			}
		});
	}
	
	
	
	
	//===========================================
	
	@Override
	public void dispose() {
	}
	@Override
	public void hide() {
	}
	@Override
	public void pause() {
	}
	@Override
	public void resume() {
	}
	@Override
	public void show() {
	}
}
