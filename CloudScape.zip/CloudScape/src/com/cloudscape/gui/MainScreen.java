package com.cloudscape.gui;

import java.util.LinkedList;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.SelectBox;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextArea;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.scenes.scene2d.ui.TextField.TextFieldListener;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.cloudscape.DeviceScreen;
import com.cloudscape.gui.GameClass;
import com.cloudscape.gui.creatorscreen.MapCreatorScreen;
import com.cloudscape.gui.gamescreen.GamePlayScreen;
import com.cloudscape.gui.levelsreen.LevelSelectScreen;
import com.cloudscape.gui.online.OnlineScreen;
import com.cloudscape.gui.signup.SignInScreen;
import com.cloudscape.gui.signup.SignUpScreen;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.actors.Grue;
import com.cloudscape.objects.actors.Knight;
import com.cloudscape.objects.actors.aliens.BeigeAlien;
import com.cloudscape.objects.actors.aliens.BlueAlien;
import com.cloudscape.objects.levels.Level;
import com.cloudscape.objects.levels.Level1;
import com.cloudscape.objects.levels.Level2;
import com.cloudscape.objects.levels.Level3;
import com.cloudscape.objects.levels.Level4;
import com.cloudscape.objects.levels.PlayerVnpcLevel;
import com.cloudscape.objects.levels.StoredLevel1Player;
import com.cloudscape.objects.levels.StoredLevel2Player;
import com.cloudscape.objects.players.NPC;
import com.cloudscape.objects.players.Player;

public class MainScreen implements Screen {
	
	Stage stage;
	Skin skin;
	
	
	
	private final static int BTN_PANEL_LEFT_MARGIN = 200;
	private final static int BUTTON_WIDTH = (int) (180 * DeviceScreen.buttonScale);
	private final static int BUTTON_HEIGHT = (int) (20 * DeviceScreen.buttonScale);
	
	private final static int BTN_PANEL_BOTTOM = 200;
	private final static int BTN_Y_SPACING = (int) (40 * DeviceScreen.buttonScale);
	
	
	public MainScreen() {
		makeItFit();
	}
	
	@Override
	public void resize(int width, int height) {
		makeItFit();
	}
	
	@Override
	public void render(float arg0) {
		Gdx.gl.glClearColor(0.2f, 0.2f, 0.2f, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
		stage.draw();
	}
	
	private void makeItFit() {
		stage = new Stage();
		Gdx.input.setInputProcessor(stage);
		skin = new Skin(Gdx.files.internal("data/uiskin.json"));
		
		
		
		
		
		
		
		TextButton levelScreen = new TextButton("Level Screen", skin);
		levelScreen.setBounds(BTN_PANEL_LEFT_MARGIN, BTN_PANEL_BOTTOM + 3*BTN_Y_SPACING, BUTTON_WIDTH, BUTTON_HEIGHT);
		stage.addActor(levelScreen);
		levelScreen.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new LevelSelectScreen());
			}
		});
		
		TextButton onlineScreen = new TextButton("Online Screen", skin);
		onlineScreen.setBounds(BTN_PANEL_LEFT_MARGIN, BTN_PANEL_BOTTOM + 2*BTN_Y_SPACING, BUTTON_WIDTH, BUTTON_HEIGHT);
		stage.addActor(onlineScreen);
		onlineScreen.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new OnlineScreen());
			}
		});
		
		TextButton signUpScreen = new TextButton("Sign Up Screen", skin);
		signUpScreen.setBounds(BTN_PANEL_LEFT_MARGIN, BTN_PANEL_BOTTOM + 1*BTN_Y_SPACING, BUTTON_WIDTH, BUTTON_HEIGHT);
		stage.addActor(signUpScreen);
		signUpScreen.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new SignUpScreen());
			}
		});
		
		TextButton signInScreen = new TextButton("Sign In Screen", skin);
		signInScreen.setBounds(BTN_PANEL_LEFT_MARGIN, BTN_PANEL_BOTTOM, BUTTON_WIDTH, BUTTON_HEIGHT);
		stage.addActor(signInScreen);
		signInScreen.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new SignInScreen());
			}
		});
		
		
		
		onlineScreen.setDisabled(true);
		signUpScreen.setDisabled(true);
		signInScreen.setDisabled(true);
		
		
	}
	
	
	
	//===========================================
	
	@Override
	public void dispose() {
	}
	@Override
	public void hide() {
	}
	@Override
	public void pause() {
	}
	@Override
	public void resume() {
	}
	@Override
	public void show() {
	}
}
