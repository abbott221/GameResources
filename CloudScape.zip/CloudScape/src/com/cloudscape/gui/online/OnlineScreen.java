package com.cloudscape.gui.online;

import java.util.LinkedList;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Net.HttpMethods;
import com.badlogic.gdx.Net.HttpRequest;
import com.badlogic.gdx.Net.HttpResponse;
import com.badlogic.gdx.Net.HttpResponseListener;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.net.HttpRequestBuilder;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.SelectBox;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextArea;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.scenes.scene2d.ui.TextField.TextFieldListener;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener.ChangeEvent;
import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.JsonReader;
import com.badlogic.gdx.utils.JsonValue;
import com.badlogic.gdx.utils.XmlReader;
import com.cloudscape.NetworkRequest;
import com.cloudscape.gui.GameClass;
import com.cloudscape.gui.MainScreen;
import com.cloudscape.gui.creatorscreen.MapCreatorScreen;
import com.cloudscape.gui.gamescreen.GamePlayScreen;
import com.cloudscape.gui.gamescreen.GameScreenHUD;
import com.cloudscape.gui.levelsreen.LevelSelectScreen;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.actors.Grue;
import com.cloudscape.objects.actors.Knight;
import com.cloudscape.objects.actors.aliens.BeigeAlien;
import com.cloudscape.objects.actors.aliens.BlueAlien;
import com.cloudscape.objects.levels.Level;
import com.cloudscape.objects.levels.Level1;
import com.cloudscape.objects.levels.Level2;
import com.cloudscape.objects.levels.Level3;
import com.cloudscape.objects.levels.Level4;
import com.cloudscape.objects.levels.PlayerVnpcLevel;
import com.cloudscape.objects.levels.StoredLevel1Player;
import com.cloudscape.objects.levels.StoredLevel2Player;
import com.cloudscape.objects.players.NPC;
import com.cloudscape.objects.players.Player;

public class OnlineScreen implements Screen {
	
	Stage stage;
	Skin skin;
	
	Stage chatHUD;
	
	
	//List<String> messages = new LinkedList<String>();
	List<String> messages;
	
	
	List<String> gameNames;
	
	SelectBox availableGames;
	
	NetworkRequest getGlobalChat;
	
	
	private OnlineScreen me;
	
	public OnlineScreen() {
		makeItFit();
		
		me = this;
		
		
		NetworkRequest getGames = new NetworkRequest("http://localhost/gamesFetch.php") {
			@Override
			public void responseHandler(HttpResponse response) {
				String test = response.getResultAsString();
				
				JsonReader reader = new JsonReader();
				JsonValue value = reader.parse( test );
				
				gameNames = new LinkedList<String>();
				
				JsonValue temp = value.child;
				
				do {
					gameNames.add(temp.get("GameName").asString());
					
					temp = temp.next;
				} while (temp != null);
				
				Gdx.app.postRunnable(new Runnable() {
					@Override
					public void run() {
						availableGames.setItems(gameNames.toArray());
					}
				});
			}
		};
		
		getGames.send();
		
		
		getGlobalChat = new NetworkRequest("http://localhost/globalChatFetch.php") {
			@Override
			public void responseHandler(HttpResponse response) {
				String test = response.getResultAsString();
				
				JsonReader reader = new JsonReader();
				JsonValue value = reader.parse( test );
				
				messages = new LinkedList<String>();
				
				JsonValue temp = value.child;
				
				do {
					//messages.add(temp.get("GameName").asString());
					messages.add(temp.get("Message").asString());
					
					temp = temp.next;
				} while (temp != null);
				
				Gdx.app.postRunnable(new Runnable() {
					@Override
					public void run() {
						//availableGames.setItems(gameNames.toArray());
						chatHUD = ChatBoxHUD.reset(messages, me);
						resetInputMultiplexer();
					}
				});
			}
		};
		
		getGlobalChat.send();
		
		
		
	}
	
	public void getGlobalChat() {
		getGlobalChat.send();
	}
	
	public void sendMessage(String sendThis) {
		
		
		NetworkRequest sendMessage = new NetworkRequest(
				"http://localhost/globalChatInsert.php?Message=" + sendThis) {
			@Override
			public void responseHandler(HttpResponse response) {
				
				
				Gdx.app.postRunnable(new Runnable() {
					@Override
					public void run() {
						//availableGames.setItems(gameNames.toArray());
						
						getGlobalChat();
						
						//chatHUD = ChatBoxHUD.reset(messages, me);
						//resetInputMultiplexer();
					}
				});
			}
		};
		
		sendMessage.send();
	}
	
	
	
	
	@Override
	public void resize(int width, int height) {
		makeItFit();
	}
	
	@Override
	public void render(float arg0) {
		Gdx.gl.glClearColor(0.2f, 0.2f, 0.2f, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
		stage.draw();
		
		chatHUD.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
		chatHUD.draw();
	}
	
	private void resetInputMultiplexer() {
		InputMultiplexer multiplexer = new InputMultiplexer();
		multiplexer.addProcessor(stage);
		multiplexer.addProcessor(chatHUD);
		Gdx.input.setInputProcessor(multiplexer);
	}
	
	private void makeItFit() {
		stage = new Stage();
		skin = new Skin(Gdx.files.internal("data/uiskin.json"));
		
		
		chatHUD = ChatBoxHUD.reset(null, this);
		resetInputMultiplexer();
		
//		InputMultiplexer multiplexer = new InputMultiplexer();
//		multiplexer.addProcessor(stage);
//		multiplexer.addProcessor(chatHUD);
//		Gdx.input.setInputProcessor(multiplexer);
		
		
		
		
		int top = Gdx.graphics.getHeight();
		
		
		
		TextButton createGame = new TextButton("Create Game", skin);
		createGame.setBounds(100, top - 100, 180, 20);
		stage.addActor(createGame);
		createGame.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new LevelSelectScreen());
			}
		});
		
		
		final SelectBox levelDropDown = new SelectBox(skin);
		levelDropDown.setItems(GameClass.getInstance().savedMaps.keySet().toArray());
		levelDropDown.setBounds(300, top - 100, 180, 20); //*4 on spacing
		stage.addActor(levelDropDown);
		
		
		
		
		
		
		
		
		
		TextButton joinGame = new TextButton("Join Game", skin);
		joinGame.setBounds(100, top - 200, 180, 20);
		stage.addActor(joinGame);
		joinGame.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new MapCreatorScreen());
			}
		});
		
		availableGames = new SelectBox(skin);
		//availableGames.setItems(GameClass.getInstance().savedMaps.keySet().toArray());
		if (gameNames == null) {
			availableGames.setItems("NONE");
		}
		//availableGames.setItems("NONE");
		
		availableGames.setBounds(300, top - 200, 180, 20); //*4 on spacing
		stage.addActor(availableGames);
		
		
		
		
		//===========================================
		
		TextButton returnButton = new TextButton("Main Menu", skin);
		returnButton.setBounds(20, top - 40, 180, 20);
		stage.addActor(returnButton);
		returnButton.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new MainScreen());
			}
		});
	}
	
	
	
	//===========================================
	
	@Override
	public void dispose() {
	}
	@Override
	public void hide() {
	}
	@Override
	public void pause() {
	}
	@Override
	public void resume() {
	}
	@Override
	public void show() {
	}
}
