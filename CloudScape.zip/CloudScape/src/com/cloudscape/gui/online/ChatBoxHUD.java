package com.cloudscape.gui.online;

import java.net.URLEncoder;
import java.util.LinkedList;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Dialog;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextArea;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.VerticalGroup;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.cloudscape.gui.GameClass;
import com.cloudscape.gui.levelsreen.LevelSelectScreen;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.Grid;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.players.Player;

public class ChatBoxHUD {
	
	private static Stage stage;
	private static Skin skin;
	
	
	
	
	private static OnlineScreen onlineScreen;
	
	
	
	
	
	public static Stage reset(List<String> messages, OnlineScreen screen) {
		stage = new Stage();
		
		skin = new Skin(Gdx.files.internal("data/uiskin.json"));
		
		//=================================================================
		
		onlineScreen = screen;
		
		int height = Gdx.graphics.getHeight();
		int width = Gdx.graphics.getWidth();
		
		
		
		Table inner = new Table();
		//VerticalGroup inner = new VerticalGroup();
		
//		ScrollPane pane = new ScrollPane(inner, skin);
//		//VerticalGroup pane = new VerticalGroup(inner, skin);
//		pane.setSize(400, 100);
//		pane.setBounds(width - 200, 20, 180, height - 40);
		
		inner.setBounds(width - 200, 20, 180, height - 40);
		
		
		//=======
		
		
		
		//list of labels to add
		if (messages != null) {
			
			Table labelTable = new Table();
			
			ScrollPane labelPane = new ScrollPane(labelTable, skin);
			labelPane.setHeight(250);
			//labelPane.ma
			inner.add(labelPane).colspan(2);
			
			System.out.println("you have messages");
			for (String message : messages) {
				labelTable.add(new Label(message, skin));
				labelTable.row();
			}
		}
		
		
		inner.row();
		
//		final TextArea xmlArea = new TextArea(
//				"aaaaa \n bbbbb \n ccccc \n ddddd \n eeeee \n ffff", skin);
		final TextArea xmlArea = new TextArea(
				"aaaaa", skin);
		//inner.add(xmlArea).minHeight(500).fill().expand();
		
		inner.add(xmlArea).colspan(2);
		
		
		
		
		
		inner.row();
		
		
		
		
		TextButton refresh = new TextButton("Refresh", skin);
		refresh.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent arg0, Actor arg1) {
				//round.endTurn();
				onlineScreen.getGlobalChat();
			}
		});
		inner.add(refresh);
		
		//inner.row();
		
		
		
		
		
		//inner.row();
		
		TextButton sendButton = new TextButton("Send", skin);
		sendButton.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent arg0, Actor arg1) {
				//round.endTurn();
				//onlineScreen.sendMessage(xmlArea.getText());
				
				System.out.println("To send: " + xmlArea.getText());
				//System.out.println("To send: " + xmlArea.getMessageText());
				
				//onlineScreen.sendMessage(xmlArea.getText());
				onlineScreen.sendMessage(URLEncoder.encode(xmlArea.getText()));
			}
		});
		inner.add(sendButton);
		
		//=======
		
		//stage.addActor(pane);
		stage.addActor(inner);
		
		
		
		
		return stage;
	}
	
	
	
	//called on create() and resize()
	//add the stage to the multiplexer
//	public static Stage reset(List<String> messages, OnlineScreen screen) {
//		stage = new Stage();
//		
//		skin = new Skin(Gdx.files.internal("data/uiskin.json"));
//		
//		//=================================================================
//		
//		onlineScreen = screen;
//		
//		int height = Gdx.graphics.getHeight();
//		int width = Gdx.graphics.getWidth();
//		
//		
//		
//		Table inner = new Table();
//		
//		ScrollPane pane = new ScrollPane(inner, skin);
//		pane.setSize(400, 100);
//		pane.setBounds(width - 200, 20, 180, height - 40);
//		
//		//=======
//		
//		TextButton refresh = new TextButton("Refresh", skin);
//		refresh.addListener(new ChangeListener() {
//			@Override
//			public void changed(ChangeEvent arg0, Actor arg1) {
//				//round.endTurn();
//				onlineScreen.getGlobalChat();
//			}
//		});
//		inner.add(refresh);
//		
//		inner.row();
//		
//		//list of labels to add
//		if (messages != null) {
//			System.out.println("you have messages");
//			for (String message : messages) {
//				inner.add(new Label(message, skin));
//				inner.row();
//			}
//		}
//		
//		
//		inner.row();
//		
////		final TextArea xmlArea = new TextArea(
////				"aaaaa \n bbbbb \n ccccc \n ddddd \n eeeee \n ffff", skin);
//		final TextArea xmlArea = new TextArea(
//				"aaaaa", skin);
//		//inner.add(xmlArea).minHeight(500).fill().expand();
//		inner.add(xmlArea);
//		
//		
//		inner.row();
//		
//		TextButton sendButton = new TextButton("Send", skin);
//		sendButton.addListener(new ChangeListener() {
//			@Override
//			public void changed(ChangeEvent arg0, Actor arg1) {
//				//round.endTurn();
//				//onlineScreen.sendMessage(xmlArea.getText());
//				
//				System.out.println("To send: " + xmlArea.getText());
//				//System.out.println("To send: " + xmlArea.getMessageText());
//				
//				//onlineScreen.sendMessage(xmlArea.getText());
//				onlineScreen.sendMessage(URLEncoder.encode(xmlArea.getText()));
//			}
//		});
//		inner.add(sendButton);
//		
//		//=======
//		
//		stage.addActor(pane);
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		//SUCCESSFULLY GETS VERTICAL, LEAVES HORIZONTAL, LEAVES NO GAPS ON SIDES OF SCROLLPANE
//		
////		Table inner = new Table();
////		
////		ScrollPane pane = new ScrollPane(inner, skin);
////		pane.setSize(400, 100);
////		
////		TextArea xmlArea = new TextArea("aaaaa \n bbbbb \n ccccc \n ddddd \n eeeee \n ffff", skin);
////		inner.add(xmlArea).minHeight(500).fill().expand();
////		
////		//Table outer = new Table();
////		//outer.add(pane).fill().expand();
////		//outer.add(pane).fill(false);
////		
////		//stage.addActor(outer);
////		stage.addActor(pane);
//		
//		
//		
//		return stage;
//	}
	
	//will do stuff when user clicks refresh button
//	public void reset() {
//		//
//	}
}
