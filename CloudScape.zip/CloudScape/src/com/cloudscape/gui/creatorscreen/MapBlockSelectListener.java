package com.cloudscape.gui.creatorscreen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.cloudscape.DeviceScreen;
import com.cloudscape.objects.Block;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.Grid;
import com.cloudscape.objects.Block.BlockState;

//extends InputAdapter
//implements InputProcessor
public class MapBlockSelectListener extends InputAdapter {
	
	MapCreatorScreen screen;
	
	//to filter clicks from drags
	boolean clickCandidate;
	
	public MapBlockSelectListener (MapCreatorScreen s) {
		screen = s;
	}
	
	@Override
	public boolean touchDown(int x, int y, int pointer, int button) {
		//System.out.println("RESET");
		clickCandidate = true;
		return false;
	}
	
	@Override
	public boolean touchDragged (int x, int y, int pointer) {
		//System.out.println("DRAGGED");
		clickCandidate = false;
		return false;
	}
	
	@Override
	public boolean touchUp (int x, int y, int pointer, int button) {
		y = Gdx.graphics.getHeight() - y;
		
		x /= DeviceScreen.scale;
		y /= DeviceScreen.scale;
		
		if (clickCandidate) {
			Grid gr = Grid.getInstance();
			Block clickedBlock = gr.getClosestBlock(x, y);
			
			if (clickedBlock != null) {
				clickedBlock.setState(BlockState.SELECT);
				screen.selected = clickedBlock;
				
				if (screen.continuousMode) {
					screen.selected.setType(MapHUD.blockTypeDropDown.getSelected().toString());
				}
			}
		}
		
		return false;
	}
}