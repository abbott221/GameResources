package com.cloudscape.gui.creatorscreen;

import java.util.LinkedList;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.CheckBox;
import com.badlogic.gdx.scenes.scene2d.ui.Dialog;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.SelectBox;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.ui.TextField.TextFieldListener;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener.ChangeEvent;
import com.cloudscape.BlockMap;
import com.cloudscape.DeviceScreen;
import com.cloudscape.BlockMap.BlockType;
import com.cloudscape.gui.GameClass;
import com.cloudscape.gui.levelsreen.LevelSelectScreen;
import com.cloudscape.objects.Block;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.Grid;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.levels.Level;
import com.cloudscape.objects.players.Player;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

public class MapHUD {
	
	public static String mapName = "Map Name";
	
	static Object[] listEntries = {"none", "grass", "dirt"};
	
	private static Stage stage;
	private static Skin skin;
	
	//private static GameRound round;
	static MapCreatorScreen screen;
	
	public static SelectBox blockTypeDropDown;
	
	//called on create() and resize()
	//add the stage to the multiplexer
	public static Stage create(MapCreatorScreen s) {
		List<String> displayNames = new LinkedList<String>();
		
		for (BlockType type : BlockMap.getInstance().getBlockTypes()) {
			displayNames.add(type.getDisplayName());
		}
		listEntries = displayNames.toArray();
		
		
		
		screen = s;
		stage = new Stage();
		
		skin = new Skin(Gdx.files.internal("data/uiskin.json"));
		
		//=======
		
		TextButton exitGame = new TextButton("Exit Creator", skin);
		exitGame.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new LevelSelectScreen());
			}
		});
		exitGame.setBounds(10, 100, 140, 20);
		stage.addActor(exitGame);
		
		TextButton export = new TextButton("Save Map", skin);
		export.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				String output = Level.printXML(screen.fakeRound);
				
				//System.out.println(output);
				GameClass.getInstance().savedMaps.put(MapHUD.mapName, output);
			}
		});
		export.setBounds(10, 130, 140, 20);
		stage.addActor(export);
		
		TextField nameField = new TextField(MapHUD.mapName, skin);
		nameField.setTextFieldListener(new TextFieldListener() {
			@Override
			public void keyTyped(TextField textField, char key) {
				if (key == '\r' || key == '\n') {
					textField.getOnscreenKeyboard().show(false);
					stage.setKeyboardFocus(null);
					
					MapHUD.mapName = textField.getText();
				}
				
				MapHUD.mapName = textField.getText();
			}
		});
		nameField.setBounds(10, 160, 140, 20);
		stage.addActor(nameField);
		
		//=======
		
		TextButton remColumn = new TextButton("Remove Column", skin);
		remColumn.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				Grid gr = Grid.getInstance();
				resizeGrid(gr.getRowCount(), gr.getColumnCount() - 1);
			}
		});
		remColumn.setBounds(10, 10, 140, 20);
		stage.addActor(remColumn);
		
		TextButton addColumn = new TextButton("Add Column", skin);
		addColumn.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				Grid gr = Grid.getInstance();
				resizeGrid(gr.getRowCount(), gr.getColumnCount() + 1);
			}
		});
		addColumn.setBounds(10, 40, 140, 20);
		stage.addActor(addColumn);
		
		TextButton remRow = new TextButton("Remove Row", skin);
		remRow.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				Grid gr = Grid.getInstance();
				resizeGrid(gr.getRowCount() - 1, gr.getColumnCount());
			}
		});
		remRow.setBounds(160, 10, 140, 20);
		stage.addActor(remRow);
		
		TextButton addRow = new TextButton("Add Row", skin);
		addRow.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				Grid gr = Grid.getInstance();
				resizeGrid(gr.getRowCount() + 1, gr.getColumnCount());
			}
		});
		addRow.setBounds(160, 40, 140, 20);
		stage.addActor(addRow);
		
		TextButton remHeight = new TextButton("Remove Height", skin);
		remHeight.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				screen.selected.height--;
			}
		});
		remHeight.setBounds(310, 10, 140, 20);
		stage.addActor(remHeight);
		
		TextButton addHeight = new TextButton("Add Height", skin);
		addHeight.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				screen.selected.height++;
			}
		});
		addHeight.setBounds(310, 40, 140, 20);
		stage.addActor(addHeight);
		
		//=======
		
		final SelectBox ownerDropDown = new SelectBox(skin);
		ownerDropDown.setItems("user", "npc");
		ownerDropDown.setBounds(Gdx.graphics.getWidth() - 160, 70, 150, 20);
		stage.addActor(ownerDropDown);
		
		final SelectBox actorDropDown = new SelectBox(skin);
		actorDropDown.setItems("none", "Knight", "Grue", "BeigeAlien", "BlueAlien", "GreenAlien", "PinkAlien", "YellowAlien");
		actorDropDown.setBounds(Gdx.graphics.getWidth() - 160, 40, 150, 20);
		stage.addActor(actorDropDown);
		
		TextButton changeActor = new TextButton("Change Actor", skin);
		changeActor.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor button) {
				if (screen.selected != null) {
					//screen.selected.setType(actorDropDown.getSelected().toString());
					//GameActor.get(className, user);
					
					if (actorDropDown.getSelected().toString().equalsIgnoreCase("none")) {
						if (screen.selected.hasOccupant()) {
							screen.selected.getOccupant().die();
						}
					} else {
						
						if (screen.selected.hasOccupant()) {
							screen.selected.getOccupant().die();
						}
						
						
						Player selectedPlayer = null;
						
						if (ownerDropDown.getSelected().toString().equalsIgnoreCase("user")) {
							selectedPlayer = screen.fakeRound.getPlayers().get(0);
						} else { //npc
							selectedPlayer = screen.fakeRound.getPlayers().get(1);
						}
						
						GameActor actor = GameActor.get(actorDropDown.getSelected().toString(), selectedPlayer);
						selectedPlayer.addActor(actor);
						//actor.moveTo(screen.selected);
						actor.setLocation(screen.selected);
						
					}
				}
			}
		});
		changeActor.setBounds(Gdx.graphics.getWidth() - 290, 40, 120, 20);
		stage.addActor(changeActor);
		
		//=======
		
		blockTypeDropDown = new SelectBox(skin);
		blockTypeDropDown.setItems(listEntries);
		blockTypeDropDown.setBounds(Gdx.graphics.getWidth() - 160, 10, 150, 20);
		stage.addActor(blockTypeDropDown);
		
		TextButton changeType = new TextButton("Change Type", skin);
		changeType.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				if (screen.selected != null) {
					screen.selected.setType(blockTypeDropDown.getSelected().toString());
				}
			}
		});
		changeType.setBounds(Gdx.graphics.getWidth() - 290, 10, 120, 20);
		stage.addActor(changeType);
		
		
		
		
		//continuousModeButton
		final CheckBox continueBtn = new CheckBox("Continuous", skin);
		continueBtn.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				screen.continuousMode = continueBtn.isChecked();
			}
		});
		continueBtn.setBounds(Gdx.graphics.getWidth() - 420, 10, 150, 20);
		stage.addActor(continueBtn);
		//reset continuous mode
		continueBtn.setChecked(false);
		screen.continuousMode = false;
		
		
		addZoomButtons();
		
		//=======
		
		return stage;
	}
	
	
	
	private static void addZoomButtons() {
		int height = Gdx.graphics.getHeight();
		int width = Gdx.graphics.getWidth();
		
		
		TextButton zoomIn = new TextButton("Zoom In", skin);
		zoomIn.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent arg0, Actor arg1) {
				DeviceScreen.scale *= 1.2f;
				DeviceScreen.displacement.scl(1.0f / 1.2f);
				//DeviceScreen.scale = 1.0f;
			}
		});
		//zoomIn.setBounds(20, height - 40, 100, 20);
		zoomIn.setBounds(width - 250, height - 40, 100, 20);
		stage.addActor(zoomIn);
		
		
		TextButton zoomOut = new TextButton("Zoom Out", skin);
		zoomOut.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent arg0, Actor arg1) {
				DeviceScreen.scale /= 1.2f;
				DeviceScreen.displacement.scl(1.2f);
				//DeviceScreen.scale = 1.0f;
			}
		});
		//zoomOut.setBounds(150, height - 40, 100, 20);
		zoomOut.setBounds(width - 120, height - 40, 100, 20);
		stage.addActor(zoomOut);
	}
	
	
	
	private static void resizeGrid(int newRowCount, int newColumnCount) {
		Grid gr = Grid.getInstance();
		Block[][] newBlocks = new Block[newRowCount][newColumnCount];
		Block[][] oldBlocks = gr.blocks;
		
		for (int i = 0; i < newRowCount; i++) {
			for (int j = 0; j < newColumnCount; j++) {
				newBlocks[i][j] = new Block(i, j);
			}
		}
		
		//use the smaller max count as the max count for the following loops
		int maxRow = gr.getRowCount();
		if (newRowCount < maxRow) {
			maxRow = newRowCount;
		}
		int maxCol = gr.getColumnCount();
		if (newColumnCount < maxCol) {
			maxCol = newColumnCount;
		}
		
		for (int i = 0; i < maxRow; i++) {
			for (int j = 0; j < maxCol; j++) {
				newBlocks[i][j] = oldBlocks[i][j];
			}
		}
		
		gr.blocks = newBlocks;
	}
}
