package com.cloudscape.gui.creatorscreen;

import java.util.LinkedList;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.cloudscape.BlockMap;
import com.cloudscape.DeviceScreen;
import com.cloudscape.gui.gamescreen.GameScreenHUD;
import com.cloudscape.objects.Block;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.Grid;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.levels.FakeLevel;
import com.cloudscape.objects.levels.Level;
import com.cloudscape.objects.levels.Level1;
import com.cloudscape.objects.players.Player;
import com.cloudscape.objects.screen.BlockSelectListener;
import com.cloudscape.objects.screen.DragController;
import com.cloudscape.objects.screen.ScrollController;
import com.badlogic.gdx.Screen;

public class MapCreatorScreen implements Screen {
	SpriteBatch batch;
	ShapeRenderer shapeBatch;
	
	//Texture img;
	Texture sky = new Texture("sepia_sky.png");
	
	//TODO will I use this object though?
	//GameRound round;
	//TODO also, should I make Grid just an instance variable inside GameRound, and make it not a singleton?
	
	public Block selected = null;
	
	DragController dragControl;
	
	Stage hud;
	public boolean continuousMode = false;
	
	GameRound fakeRound;
	
	public MapCreatorScreen() {
		Level temp = new FakeLevel();
		fakeRound = temp.makeLevel();
		
		makeItFit();
	}
	
	public MapCreatorScreen(String mapName, String xml) {
		FakeLevel temp = new FakeLevel();
		fakeRound = temp.makeLevel(xml);
		
		makeItFit();
		
		MapHUD.mapName = mapName;
	}
	
	@Override
	public void render(float arg0) {
		Gdx.gl.glClearColor(0.2f, 0.2f, 0.2f, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		
		
		batch.getProjectionMatrix().scl(DeviceScreen.scale);
		shapeBatch.setProjectionMatrix(shapeBatch.getProjectionMatrix().scl(DeviceScreen.scale));
		
		
		
		batch.begin();
		
		//draw the sky
		float skyScale = Math.max(Gdx.graphics.getHeight() * 1.0f / sky.getHeight(), Gdx.graphics.getWidth() * 1.0f / sky.getWidth());
		batch.draw(sky, 0, 0, sky.getWidth() * skyScale / DeviceScreen.scale, sky.getHeight() * skyScale / DeviceScreen.scale);
		//batch.draw(sky, 0, 0, sky.getWidth() * 2.5f, sky.getHeight() * 2.5f);
		
		Grid gr = Grid.getInstance();
		int rowCount = gr.getRowCount();
		int columnCount = gr.getColumnCount();
		
		batch.end();
		
		
		
		//draw blocks row by row
		for (int r = 0; r < rowCount; r++) {
			//draw the block images
			batch.begin();
			for (int c = 0; c < columnCount; c++) {
				if (gr.getBlockAt(r, c) != null) {
					Block b = gr.getBlockAt(r, c);
					
					b.drawSelf(batch);
				}
			}
			batch.end();
			
			//draw the highlights on top of the blocks
			shapeBatch.begin(ShapeType.Filled);
			for (int c = 0; c < columnCount; c++) {
				if (selected != null && selected.column == c && selected.row == r) {
					selected.drawActiveState(shapeBatch);
				}
			}
			shapeBatch.end();
			
			//draw outlines on top of the blocks
			shapeBatch.begin(ShapeType.Filled);
			shapeBatch.setColor(Color.BLACK);
			for (int c = 0; c < columnCount; c++) {
				if (gr.getBlockAt(r, c) != null) {
					Block b = gr.getBlockAt(r, c);
					if (b != null) {
						b.drawOutline(shapeBatch);
					}
				}
			}
			shapeBatch.end();
		}
		
		
		
		//draw the actors for each player
		batch.begin();
		for (Player p : fakeRound.getPlayers()) {
			for (GameActor actor : p.getActors()) {
				actor.drawSelf(batch);
			}
		}
		batch.end();
		
		
		
		batch.getProjectionMatrix().scl(1.0f / DeviceScreen.scale);
		shapeBatch.setProjectionMatrix(shapeBatch.getProjectionMatrix().scl(1.0f / DeviceScreen.scale));
		
		
		
		hud.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
		hud.draw();
	}
	
	//TODO centering the screen on the center of the grid or something like that
	@Override
	public void resize(int width, int height) {
		makeItFit();
	}
	
	public void makeItFit() {
		batch = new SpriteBatch();
		shapeBatch = new ShapeRenderer();
		
		hud = MapHUD.create(this);
		
		InputMultiplexer multiplexer = new InputMultiplexer();
		multiplexer.addProcessor(hud);
		multiplexer.addProcessor(new MapBlockSelectListener(this));
		multiplexer.addProcessor(new DragController());
		multiplexer.addProcessor(new ScrollController());
		Gdx.input.setInputProcessor(multiplexer);
	}
	
	//===========================================
	
	@Override
	public void dispose() {
	}
	@Override
	public void hide() {
	}
	@Override
	public void pause() {
	}
	@Override
	public void resume() {
	}
	@Override
	public void show() {
	}
}
