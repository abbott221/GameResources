package com.cloudscape.gui;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.badlogic.gdx.Game;
import com.cloudscape.Commons;
import com.cloudscape.gui.creatorscreen.MapHUD;
import com.cloudscape.gui.levelsreen.LevelSelectScreen;

//a singleton, controller for the screens, and will possibly be a container for variables shared across screens...
//although variables shared across screens could possibly be a singleton as well
public class GameClass extends Game {
	
	public String username = "user";
	
	public String passHash = "";
	
	
	
	public Map<String, String> savedMaps = new LinkedHashMap<String, String>();
	
	private static GameClass GAME = null;
	
	private GameClass() {
		//singleton
	}
	public static GameClass getInstance() {
		if (GAME == null) {
			GAME = new GameClass();
		}
		return GAME;
	}
	
	
	@Override
	public void create() {
		this.setScreen(new MainScreen());
		
		GameClass.getInstance().addMaps();
	}
	
	public void addMaps() {
		savedMaps.put("Level 1", Commons.dumpFile("levels/level01.xml"));
		savedMaps.put("Level 2", Commons.dumpFile("levels/level02.xml"));
		savedMaps.put("Level 3", Commons.dumpFile("levels/level03.xml"));
		savedMaps.put("Level 4", Commons.dumpFile("levels/level04.xml"));
		savedMaps.put("Level 5", Commons.dumpFile("levels/level05.xml"));
		savedMaps.put("Level 6", Commons.dumpFile("levels/level06.xml"));
		savedMaps.put("Level 7", Commons.dumpFile("levels/level07.xml"));
		savedMaps.put("Level 8", Commons.dumpFile("levels/level08.xml"));
		savedMaps.put("Level 9", Commons.dumpFile("levels/level09.xml"));
		savedMaps.put("Level 10", Commons.dumpFile("levels/level10.xml"));
		savedMaps.put("Level 11", Commons.dumpFile("levels/level11.xml"));
		savedMaps.put("Level 12", Commons.dumpFile("levels/level12.xml"));
	}
	
}
