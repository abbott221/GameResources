package com.cloudscape.gui.gamescreen;

import java.util.LinkedList;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Dialog;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.cloudscape.DeviceScreen;
import com.cloudscape.gui.GameClass;
import com.cloudscape.gui.levelsreen.LevelSelectScreen;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.Grid;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.players.Player;

public class GameScreenHUD {
	
	private static Stage stage;
	private static Skin skin;
	
	private static GameRound round;
	
	private static List<Label> stats = new LinkedList<Label>();
	
	private static Label currentPlayerLabel;
	private static Label currentPlayerValue;
	
	//called on create() and resize()
	//add the stage to the multiplexer
	public static Stage create(GameRound r) {
		round = r;
		stage = new Stage();
		
		skin = new Skin(Gdx.files.internal("data/uiskin.json"));
		
		TextButton exit = new TextButton("Exit Game", skin);
		exit.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent arg0, Actor arg1) {
				Dialog prompt = new Dialog("Exit Game", skin, "dialog") {
					protected void result (Object result) {
						if (result.equals(true)) {
							GameClass.getInstance().setScreen(new LevelSelectScreen());
						}
					}
				};
				prompt.text("Are you sure?");
				prompt.button("Yes", true);
				prompt.button("No", false);
				prompt.show(stage);
				prompt.setSize(200f, 100f);
			}
		});
		exit.setBounds(20, 20, 100, 20);
		stage.addActor(exit);
		
		TextButton turnButton = new TextButton("End Turn", skin);
		turnButton.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent arg0, Actor arg1) {
				round.endTurn();
			}
		});
		turnButton.setBounds(150, 20, 100, 20);
		stage.addActor(turnButton);
		
		for (Player player : round.getPlayers()) {
			for (GameActor actor : player.getActors()) {
				actor.ownerDisplay = new Label(player.username , skin);
				
				Vector2 tc = actor.getTopCenter();
				float halfWidth = actor.ownerDisplay.getWidth() / 2;
				
				actor.ownerDisplay.setPosition(tc.x - halfWidth, tc.y + 20);
				
				stage.addActor(actor.ownerDisplay);
			}
		}
		
		//=======
		
		int height = Gdx.graphics.getHeight();
		int width = Gdx.graphics.getWidth();
		
		currentPlayerLabel = new Label("Current Player: ", skin);
		currentPlayerLabel.setPosition(350, height - 30);
		stage.addActor(currentPlayerLabel);
		
		currentPlayerValue = new Label(r.currentPlayer.username, skin);
		currentPlayerValue.setPosition(490, height - 30);
		stage.addActor(currentPlayerValue);
		
		if (round.selected != null) {
			addActorInfoLabel();
		}
		
		
		TextButton zoomIn = new TextButton("Zoom In", skin);
		zoomIn.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent arg0, Actor arg1) {
				DeviceScreen.scale *= 1.2f;
				DeviceScreen.displacement.scl(1.0f / 1.2f);
				//DeviceScreen.scale = 1.0f;
			}
		});
		//zoomIn.setBounds(20, height - 40, 100, 20);
		zoomIn.setBounds(width - 250, height - 40, 100, 20);
		stage.addActor(zoomIn);
		
		
		TextButton zoomOut = new TextButton("Zoom Out", skin);
		zoomOut.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent arg0, Actor arg1) {
				DeviceScreen.scale /= 1.2f;
				DeviceScreen.displacement.scl(1.2f);
				//DeviceScreen.scale = 1.0f;
			}
		});
		//zoomOut.setBounds(150, height - 40, 100, 20);
		zoomOut.setBounds(width - 120, height - 40, 100, 20);
		stage.addActor(zoomOut);
		
		
		return stage;
	}
	
	public static void updateOwnerDisplays() {
		Vector2 tc = new Vector2();
		for (Player player : round.getPlayers()) {
			for (GameActor actor : player.getActors()) {
				tc.y = (actor.motionVector.y * DeviceScreen.scale) + (actor.getImageHeight() + 20) * DeviceScreen.scale;
				tc.x = (actor.motionVector.x * DeviceScreen.scale) + ((actor.getImageWidth() / 2) * DeviceScreen.scale - (actor.ownerDisplay.getWidth() / 2));
				
				actor.ownerDisplay.setPosition(tc.x, tc.y);
			}
		}
	}
	
	public static void updateCurrentPlayer() {
		currentPlayerValue.setText(round.currentPlayer.username);
	}
	
	public static void removeActorInfoLabel() {
		for (Label label : stats) {
			label.remove();
		}
	}
	
	public static void addActorInfoLabel() {
		stats = new LinkedList<Label>();
		
		GameActor actor = round.selected.getOccupant();
		
		//height of the text seems to be 20
		putLabel("Owner:", 10, 30);
		putLabel(actor.owner.username, 90, 30);
		putLabel("Health:", 10, 50);
		putLabel(actor.healthCurrent + "/" + actor.healthMax, 90, 50);
		putLabel("Energy:", 10, 70);
		putLabel(actor.energyCurrent + "/" + actor.energyMax, 90, 70);
		
		putLabel("Attack Range:", 10, 90);
		putLabel(String.valueOf(actor.attackRange), 125, 90);
		putLabel("Attack Power:", 10, 110);
		putLabel(String.valueOf(actor.attackPower), 125, 110);
		putLabel("Attack Cost:", 10, 130);
		putLabel(String.valueOf(actor.attackEnergyCost), 125, 130);
		putLabel("Move Cost:", 10, 150);
		putLabel(String.valueOf(actor.moveEnergyCost), 125, 150);
	}
	
	private static void putLabel(String text, int x, int y) {
		Label label = new Label(text, skin);
		int height = Gdx.graphics.getHeight();
		
		label.setPosition(x, height - y);
		stage.addActor(label);
		
		stats.add(label);
	}
	
	public static void gameEnd(Player winner) {
		Dialog prompt = new Dialog("Game has ended", skin, "dialog") {
			protected void result (Object object) {
				GameClass.getInstance().setScreen(new LevelSelectScreen());
				//System.gc();
			}
		};
		prompt.text("Winner: " + winner.username);
		prompt.button("OK", null);
		prompt.show(stage);
		prompt.setSize(200f, 100f);
	}
}
