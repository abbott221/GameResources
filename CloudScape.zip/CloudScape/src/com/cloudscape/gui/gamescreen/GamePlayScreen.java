package com.cloudscape.gui.gamescreen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.cloudscape.BlockMap;
import com.cloudscape.Commons;
import com.cloudscape.DeviceScreen;
import com.cloudscape.objects.Block;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.Grid;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.levels.Level;
import com.cloudscape.objects.players.Player;
import com.cloudscape.objects.screen.BlockSelectListener;
import com.cloudscape.objects.screen.DragController;
import com.cloudscape.objects.screen.ScrollController;
import com.badlogic.gdx.Screen;

public class GamePlayScreen implements Screen {
	SpriteBatch batch;
	ShapeRenderer shapeBatch;
	
	Texture sepiaSky = new Texture("sepia_sky.png");
	Texture greySky = new Texture("grey_sky.png");
	Texture sky = sepiaSky;
	Texture trees = new Texture("trees.jpg");
	
	//TODO will I use this object though?
	GameRound round;
	//TODO also, should I make Grid just an instance variable inside GameRound, and make it not a singleton?
	
	DragController dragControl;
	
	Stage hud;
	
	boolean adjusting = false;
	float skyTime = 0.0f;
	float transparencyAchieved = 0.0f;
	
	public GamePlayScreen(GameRound r) {
		round = r;
		
		makeItFit();
	}
	
	public GamePlayScreen(Level l) {
		round = l.makeLevel();
		
		makeItFit();
		
		round.currentPlayer.turnStart(round);
	}
	
	@Override
	public void render(float arg0) {
		Commons.npcLock.lock();
		
		Gdx.gl.glClearColor(0.2f, 0.2f, 0.2f, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		GameScreenHUD.updateOwnerDisplays();
		
		
		
		batch.getProjectionMatrix().scl(DeviceScreen.scale);
		shapeBatch.setProjectionMatrix(shapeBatch.getProjectionMatrix().scl(DeviceScreen.scale));
		
		
		
		batch.begin();
		
		
		
		colorSky();
		
		
		
		Grid gr = Grid.getInstance();
		int rowCount = gr.getRowCount();
		int columnCount = gr.getColumnCount();
		
		batch.end();
		
		
		
		//draw blocks row by row
		for (int r = 0; r < rowCount; r++) {
			
			
			
			
			
			//draw the block images
			batch.begin();
			
			Color color = batch.getColor();
			
			float transparency = slowedDeathRatio();
			transparency = transparency * 1.5f;
			if (transparency > 1.0f) {
				transparency = 1.0f;
			}
			
			//batch.setColor(0.35f,0.35f,0.35f,transparency);
			//transparency = 1.0f - transparency;
			//transparency = 1.0f - (1.0f-0.35f)*transparency;
			transparency = 1.0f - (1.0f-0.5f)*transparency;
			for (int c = 0; c < columnCount; c++) {
				if (gr.getBlockAt(r, c) != null) {
					Block b = gr.getBlockAt(r, c);
					
					batch.setColor(color);
					b.drawSelf(batch);
					//batch.setColor(0.35f,0.35f,0.35f,transparency);
					//batch.setColor(0.35f * transparency,0.35f * transparency,0.35f * transparency,1.0f);
					batch.setColor(transparency, transparency, transparency, 1.0f);
					b.drawSelf(batch);
				}
			}
			batch.setColor(color);
			
			batch.end();
			
			
			
			
//			batch.begin();
//			Color color = batch.getColor();
//			
//			float transparency = slowedDeathRatio();
//			transparency = transparency * 1.5f;
//			if (transparency > 1.0f) {
//				transparency = 1.0f;
//			}
//			
//			//batch.setColor(Color.GRAY);
//			//batch.setColor(0.5f,0.5f,0.5f,transparency);
//			batch.setColor(0.35f,0.35f,0.35f,transparency);
//			for (int c = 0; c < columnCount; c++) {
//				if (gr.getBlockAt(r, c) != null) {
//					Block b = gr.getBlockAt(r, c);
//					
//					b.drawSelf(batch);
//				}
//			}
//			
//			batch.setColor(color);
//			batch.end();
			
			
			
			
			//draw the highlights on top of the blocks
			if (round.activeBlocks.size() > 0) {
				Gdx.gl.glEnable(GL20.GL_BLEND);
				Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
				shapeBatch.begin(ShapeType.Filled);
				
				for (int c = 0; c < columnCount; c++) {
					if (round.activeBlocks.contains(gr.getBlockAt(r, c))) {
						gr.getBlockAt(r, c).drawActiveState(shapeBatch);
					}
				}
				
				shapeBatch.end();
				Gdx.gl.glDisable(GL20.GL_BLEND);
			}
			
			//draw outlines on top of the blocks
			shapeBatch.begin(ShapeType.Filled);
			shapeBatch.setColor(Color.BLACK);
			for (int c = 0; c < columnCount; c++) {
				if (gr.getBlockAt(r, c) != null) {
					Block b = gr.getBlockAt(r, c);
					if (b != null && b.getType() != BlockMap.TypeName.NONE) {
						b.drawOutline(shapeBatch);
					}
				}
			}
			shapeBatch.end();
		}
		
		
		
		//draw the actors for each player
		batch.begin();
		for (Player p : round.getPlayers()) {
			for (GameActor actor : p.getActors()) {
				actor.drawSelf(batch);
			}
		}
		batch.end();
		
		//draw the bars and stuff for each actor of each player
		shapeBatch.begin(ShapeType.Filled);
		for (Player p : round.getPlayers()) {
			for (GameActor actor : p.getActors()) {
				actor.drawBars(shapeBatch);
			}
		}
		shapeBatch.end();
		
		
		
		batch.getProjectionMatrix().scl(1.0f / DeviceScreen.scale);
		shapeBatch.setProjectionMatrix(shapeBatch.getProjectionMatrix().scl(1.0f / DeviceScreen.scale));
		
		
		
		hud.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
		hud.draw();
		
		Commons.npcLock.unlock();
	}
	
	
	private float slowedDeathRatio() {
//		if (transparencyAchieved < 0.125f) {
//			//it takes 10 seconds to change 1.0f
//			//it takes 1 second to change 0.1f
//			skyTime += Gdx.graphics.getDeltaTime() / 10;
//		} else {
//			//it takes 3 seconds to change 0.1f
//			skyTime += Gdx.graphics.getDeltaTime() / 30;
//		}
		skyTime += Gdx.graphics.getDeltaTime() / 30;
		
		Player mainPlayer = round.getPlayers().get(0);
		int sumCurrent = 0;
		int sumMax = mainPlayer.maxTeamHealth;
		for (GameActor actor : mainPlayer.getActors()) {
			sumCurrent += actor.healthCurrent;
		}
		
		
		
		
		float transparency = 1.0f - (sumCurrent * 1.0f / sumMax);
		
		//transparency is going from 0.0f to 1.0f
		float diff = transparency - transparencyAchieved;
		
		//begin new adjusting period
		if (diff > 0 && adjusting == false) {
			adjusting = true;
			skyTime = 0.0f;
		}
		
		if (diff > skyTime) {
			//diff = skyTime;
			transparency = transparencyAchieved + skyTime;
		} else {
			transparencyAchieved = transparency;
			adjusting = false;
		}
		
		
		
		return transparency;
	}
	
	private void colorSky() {
		
		Color color = new Color(batch.getColor());
		
		//draw the sky
		float skyScale = Math.max(Gdx.graphics.getHeight() * 1.0f / sky.getHeight(),
				Gdx.graphics.getWidth() * 1.0f / sky.getWidth());
		batch.draw(sky, 0, 0,
				sky.getWidth() * skyScale / DeviceScreen.scale,
				sky.getHeight() * skyScale / DeviceScreen.scale);
		
		
		
		float transparency = slowedDeathRatio();
		
		
		//================
		
		transparency = transparency * 1.5f;
		if (transparency > 1.0f) {
			transparency = 1.0f;
		}
		
		//================
		
		
		//r,g,b,a
		//a = 0.0 -> 1.0
		//r = 1.0 -> 0.5
		batch.setColor(0.5f,0.0f,0.0f,transparency);
		batch.draw(greySky, 0, 0,
				greySky.getWidth() * skyScale / DeviceScreen.scale,
				greySky.getHeight() * skyScale / DeviceScreen.scale);
		
		batch.setColor(color);
	}
	
	
	//TODO centering the screen on the center of the grid or something like that
	@Override
	public void resize(int width, int height) {
		makeItFit();
	}
	
	public void makeItFit() {
		batch = new SpriteBatch();
		shapeBatch = new ShapeRenderer();
		
		hud = GameScreenHUD.create(round);
		
		InputMultiplexer multiplexer = new InputMultiplexer();
		multiplexer.addProcessor(hud);
		multiplexer.addProcessor(new BlockSelectListener(round));
		multiplexer.addProcessor(new DragController());
		multiplexer.addProcessor(new ScrollController());
		Gdx.input.setInputProcessor(multiplexer);
	}
	
	//===========================================
	
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void hide() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void resume() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}
	
}
