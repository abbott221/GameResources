package com.cloudscape.gui.signup;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedList;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Net.HttpResponse;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Dialog;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.SelectBox;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextArea;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.scenes.scene2d.ui.TextField.TextFieldListener;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener.ChangeEvent;
import com.cloudscape.NetworkRequest;
import com.cloudscape.gui.GameClass;
import com.cloudscape.gui.MainScreen;
import com.cloudscape.gui.creatorscreen.MapCreatorScreen;
import com.cloudscape.gui.gamescreen.GamePlayScreen;
import com.cloudscape.gui.levelsreen.LevelSelectScreen;
import com.cloudscape.gui.online.OnlineScreen;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.actors.Grue;
import com.cloudscape.objects.actors.Knight;
import com.cloudscape.objects.actors.aliens.BeigeAlien;
import com.cloudscape.objects.actors.aliens.BlueAlien;
import com.cloudscape.objects.levels.Level;
import com.cloudscape.objects.levels.Level1;
import com.cloudscape.objects.levels.Level2;
import com.cloudscape.objects.levels.Level3;
import com.cloudscape.objects.levels.Level4;
import com.cloudscape.objects.levels.PlayerVnpcLevel;
import com.cloudscape.objects.levels.StoredLevel1Player;
import com.cloudscape.objects.levels.StoredLevel2Player;
import com.cloudscape.objects.players.NPC;
import com.cloudscape.objects.players.Player;

public class SignInScreen implements Screen {
	
	Stage stage;
	Skin skin;
	
	
	
	public SignInScreen() {
		makeItFit();
	}
	
	@Override
	public void resize(int width, int height) {
		makeItFit();
	}
	
	@Override
	public void render(float arg0) {
		Gdx.gl.glClearColor(0.2f, 0.2f, 0.2f, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
		stage.draw();
	}
	
	private void makeItFit() {
		stage = new Stage();
		Gdx.input.setInputProcessor(stage);
		skin = new Skin(Gdx.files.internal("data/uiskin.json"));
		
		
		
		
		
		
		
		
		
		
		int height = Gdx.graphics.getHeight();
		int width = Gdx.graphics.getWidth();
		
		
		Label userLabel = new Label("Username: ", skin);
		userLabel.setPosition(50, height - 100);
		stage.addActor(userLabel);
		
		final TextField userField = new TextField("user", skin);
		userField.setBounds(200, height - 100, 200, 20);
		stage.addActor(userField);
		
		
		
		Label passLabel = new Label("Password: ", skin);
		passLabel.setPosition(50, height - 150);
		stage.addActor(passLabel);
		
		final TextField passField = new TextField("", skin);
		passField.setBounds(200, height - 150, 200, 20);
		passField.setPasswordMode(true);
		passField.setPasswordCharacter('*');
		passField.setMessageText("password");
		stage.addActor(passField);
		
		
		
		TextButton submitButton = new TextButton("Submit", skin);
		submitButton.setBounds(100, height - 400, 200, 20);
		stage.addActor(submitButton);
		submitButton.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				//GameClass.getInstance().setScreen(new LevelSelectScreen());
				
				//try to make an account
				
				byte[] bytesOfMessage;
				byte[] thedigest = null;
				try {
					bytesOfMessage = passField.getText().getBytes("UTF-8");
					MessageDigest md = MessageDigest.getInstance("MD5");
					thedigest = md.digest(bytesOfMessage);
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				} catch (NoSuchAlgorithmException e) {
					e.printStackTrace();
				}
				
				System.out.println(thedigest.toString());
				attemptSignIn(userField.getText(), thedigest.toString());
			}
		});
		
		
		
		
		
		
		TextButton returnButton = new TextButton("Main Menu", skin);
		returnButton.setBounds(20, height - 40, 180, 20);
		stage.addActor(returnButton);
		returnButton.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new MainScreen());
			}
		});
		
	}
	
	public void attemptSignIn(final String user, final String pass) {
		
		//onlineScreen.sendMessage(URLEncoder.encode(xmlArea.getText()));
		
		StringBuilder url = new StringBuilder("http://localhost/signIn.php?");
		url.append("UserName=" + URLEncoder.encode(user) + "&");
		url.append("Password=" + URLEncoder.encode(pass));
		
		System.out.println(url);
		
		NetworkRequest sendMessage = new NetworkRequest(url.toString()) {
			@Override
			public void responseHandler(HttpResponse response) {
				
				String test = response.getResultAsString();
				
				boolean resultMod = true;
				
				System.out.println("TEST: " + test);
				
				if (!test.equals("null")) {
					resultMod = true;
				} else {
					resultMod = false;
				}
				
				final boolean result = resultMod;
				
				Gdx.app.postRunnable(new Runnable() {
					@Override
					public void run() {
						
						String title = "Account Creation";
						String innerText = "";
						
						if (result) {
							innerText = "Successfully created account.";
							
							GameClass.getInstance().username = user;
							GameClass.getInstance().passHash = pass;
						} else {
							innerText = "Failed to create account. Username most likely already exists.";
						}
						
						
						Dialog prompt = new Dialog(title, skin, "dialog");
						prompt.text(innerText);
						prompt.button("OK", true);
						prompt.show(stage);
						//prompt.setSize(200f, 100f);
						
						
					}
				});
			}
		};
		
		sendMessage.send();
	}
	
	
	
	//===========================================
	
	@Override
	public void dispose() {
	}
	@Override
	public void hide() {
	}
	@Override
	public void pause() {
	}
	@Override
	public void resume() {
	}
	@Override
	public void show() {
	}
}
