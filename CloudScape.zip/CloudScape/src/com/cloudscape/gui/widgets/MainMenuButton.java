package com.cloudscape.gui.widgets;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener.ChangeEvent;
import com.cloudscape.DeviceScreen;
import com.cloudscape.gui.GameClass;
import com.cloudscape.gui.MainScreen;

public class MainMenuButton extends TextButton {
	
	public MainMenuButton(Skin skin) {
		super("Main Menu", skin);
		
		int top = Gdx.graphics.getHeight();
		
		this.setBounds(20, top - (20 + 20 * DeviceScreen.buttonScale), 180 * DeviceScreen.buttonScale, 20 * DeviceScreen.buttonScale);
		this.addListener(new ChangeListener() {
			@Override
			public void changed(ChangeEvent event, Actor actor) {
				GameClass.getInstance().setScreen(new MainScreen());
			}
		});
	}
	
}
