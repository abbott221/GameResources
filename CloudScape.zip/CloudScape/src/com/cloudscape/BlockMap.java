package com.cloudscape;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.badlogic.gdx.graphics.Texture;


//map of BlockTypes
public class BlockMap {
	
	public enum TypeName {
		GRASS, DIRT, AUTUMN, ROCK, SAND, SNOW, STONE, WATER, NONE, MAGIC, LAVA
	}
	
	private static BlockMap map;
	
	public static BlockMap getInstance() {
		if (map == null) {
			map = new BlockMap();
		}
		return map;
	}
	
	public class BlockType {
		private TypeName enumName;
		private String xmlName;
		private String texturePath;
		private String displayName;
		
		private Texture texture;
		
		BlockType(TypeName iEnumName, String iXmlName, String iTexturePath, String iDisplayName) {
			this.enumName = iEnumName;
			this.xmlName = iXmlName;
			this.texturePath = iTexturePath;
			if (iTexturePath != null) {
				this.texture = new Texture(iTexturePath);
			}
			this.displayName = iDisplayName;
		}
		
		public TypeName getEnumName() {
			return enumName;
		}
		public void setEnumName(TypeName internalName) {
			this.enumName = internalName;
		}
		
		public String getXmlName() {
			return xmlName;
		}
		public void setXmlName(String index) {
			this.xmlName = index;
		}
		
		public String getTexturePath() {
			return texturePath;
		}
		public void setTexturePath(String name) {
			this.texturePath = name;
			this.texture = new Texture(name);
		}
		public Texture getTexture() {
			return texture;
		}
		
		public String getDisplayName() {
			return displayName;
		}
		public void setDisplayName(String str) {
			this.displayName = str;
		}
	}
	
	private List<BlockType> blockTypes;
	
	private BlockMap() {
		blockTypes = new LinkedList<BlockType>();
		
		blockTypes.add(new BlockType(
				TypeName.GRASS, "grass", "blocks/tileGrass.png", "Grass"));
		blockTypes.add(new BlockType(
				TypeName.DIRT, "dirt", "blocks/tileDirt.png", "Dirt"));
		blockTypes.add(new BlockType(
				TypeName.NONE, "none", null, "None"));
		
		blockTypes.add(new BlockType(
				TypeName.AUTUMN, "autumn", "blocks/tileAutumn.png", "Autumn"));
		blockTypes.add(new BlockType(
				TypeName.ROCK, "rock", "blocks/tileRock.png", "Rock"));
		blockTypes.add(new BlockType(
				TypeName.SAND, "sand", "blocks/tileSand.png", "Sand"));
		blockTypes.add(new BlockType(
				TypeName.SNOW, "snow", "blocks/tileSnow.png", "Snow"));
		blockTypes.add(new BlockType(
				TypeName.STONE, "stone", "blocks/tileStone.png", "Stone"));
		blockTypes.add(new BlockType(
				TypeName.WATER, "water", "blocks/tileWater.png", "Water"));
		
		blockTypes.add(new BlockType(
				TypeName.MAGIC, "magic", "blocks/tileMagic.png", "Magic"));
		blockTypes.add(new BlockType(
				TypeName.LAVA, "lava", "blocks/tileLava.png", "Lava"));
	}
	
	public List<BlockType> getBlockTypes() {
		return blockTypes;
	}
	
	public BlockType getTypeByEnum(TypeName name) {
		for (BlockType def : blockTypes) {
			if (def.getEnumName() == name) {
				return def;
			}
		}
		//return null;
		return getTypeByEnum(TypeName.NONE);
	}
	
	public BlockType getTypeByXML(String index) {
		for (BlockType def : blockTypes) {
			if (def.getXmlName().equalsIgnoreCase(index)) {
				return def;
			}
		}
		return null;
	}
	
	public static List<TypeName> getImmovable() {
		List<TypeName> immovable = new LinkedList<TypeName>();
		
		immovable.add(TypeName.NONE);
		immovable.add(TypeName.WATER);
		immovable.add(TypeName.LAVA);
		
		return immovable;
	}
}



