package com.cloudscape;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;

public class DeviceScreen {
	
	//x, y -- width, height
	
	public static float scale = 1.0f;
	public static Vector3 displacement = new Vector3(200, 200, 0); //initial displacement of the grid in the constructor
	
	
	public static float buttonScale = 1.5f;
	
	
	//TODO add stuff for row, column to and from pixel location
	
}
