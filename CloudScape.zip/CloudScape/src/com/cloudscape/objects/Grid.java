package com.cloudscape.objects;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.XmlReader;
import com.badlogic.gdx.utils.XmlReader.Element;
import com.cloudscape.BlockMap;
import com.cloudscape.objects.actors.GameActor;

public class Grid {
	
	public enum Direction {
		RIGHT, UPPER_RIGHT, UPPER_LEFT, LEFT, LOWER_LEFT, LOWER_RIGHT
	}
	
	//0,0 is in top left, so y decreases going up on the screen
	//this is x, y, not row, column
	public Block[][] blocks;
	
	
	public int getRowCount() {
		return blocks.length;
	}
	public int getColumnCount() {
		return blocks[0].length;
	}
	
	//=====================================================================
	
	/*
	 * Singleton stuff
	 */
	private static final Grid INSTANCE = new Grid();
	private Grid() {
		//
	}
	public static Grid getInstance() {
		return INSTANCE;
	}
	
	//=====================================================================
	
	
	
	
	public GameActor getActorAt(int r, int c) {
		return getBlockAt(r, c).getOccupant();
	}
	
	//row, column
	public Block getBlockAt(int r, int c) {
		if (0 <= c && c < this.getColumnCount()) {
			if (0 <= r && r < this.getRowCount()) {
				return blocks[r][c];
			}
		}
		return null;
		
		
		//return blocks[x][y];
	}
	
	public Block getBlockAt(Block origin, Direction dir) {
		if (dir == Direction.RIGHT) {
			return this.getBlockAt(origin.row, origin.column + 1);
		} else if (dir == Direction.LEFT) {
			return this.getBlockAt(origin.row, origin.column - 1);
		}
		
		else {
			//if even, subtract 1 from x
			int newR = 0;
			int newC = 0;
			
			if (dir == Direction.UPPER_RIGHT) {
				newR = origin.row - 1;
				newC = origin.column + 1;
			} else if (dir == Direction.UPPER_LEFT) {
				newR = origin.row - 1;
				newC = origin.column;
			}
			
			else if (dir == Direction.LOWER_RIGHT) {
				newR = origin.row + 1;
				newC = origin.column + 1;
			} else if (dir == Direction.LOWER_LEFT) {
				newR = origin.row + 1;
				newC = origin.column;
			}
			
			if (origin.row % 2 == 0) {
				newC -= 1;
			}
			
			return this.getBlockAt(newR, newC);
		}
		
		//return null;
	}
	
	//public block
	public List<Block> getAdjacentOnGrid(Block origin) {
		List<Block> adjacent = new LinkedList<Block>();
		
		adjacent.add(this.getBlockAt(origin, Direction.LEFT));
		adjacent.add(this.getBlockAt(origin, Direction.RIGHT));
		
		adjacent.add(this.getBlockAt(origin.row + 1, origin.column));
		adjacent.add(this.getBlockAt(origin.row - 1, origin.column));
		
		//1 less if even
		if (origin.row % 2 == 0) {
			adjacent.add(this.getBlockAt(origin.row + 1, origin.column - 1));
			adjacent.add(this.getBlockAt(origin.row - 1, origin.column - 1));
		} else {
			adjacent.add(this.getBlockAt(origin.row + 1, origin.column + 1));
			adjacent.add(this.getBlockAt(origin.row - 1, origin.column + 1));
		}
		
		while (adjacent.contains(null)) {
			adjacent.remove(null);
		}
		
		return adjacent;
	}
	
	public List<Block> getAdjacentInteractable(Block origin) {
		List<Block> possible = getAdjacentOnGrid(origin);
		
		List<Block> outOfHeightRange = new LinkedList<Block>();
		for (Block b : possible) {
			if (Math.abs(origin.height - b.height) > 1) {
				outOfHeightRange.add(b);
			}
		}
		possible.removeAll(outOfHeightRange);
		
		return possible;
	}
	
	public List<Block> inRangeFilter(Block origin, List<Block> possible) {
		//List<Block> possible = getAdjacentOnGrid(origin);
		
		List<Block> outOfHeightRange = new LinkedList<Block>();
		for (Block b : possible) {
			if (Math.abs(origin.height - b.height) > 1) {
				outOfHeightRange.add(b);
			}
		}
		possible.removeAll(outOfHeightRange);
		
		return possible;
	}
	
	public Block getClosestBlock(int x, int y) {
		Block clickedBlock = null;
		
		int rowCount = getRowCount();
		int colCount = getColumnCount();
		for (int r = 0; r < rowCount; r++) {
			for (int c = 0; c < colCount; c++) {
				Block b = getBlockAt(r, c);
				
				Vector2 block = b.getFocalPoint();
				Vector2 input = new Vector2(x, y);
				Vector2 diff = block.sub(input);
				
				//pythagorean theorem
				int sideC = b.STAGGERED_WIDTH / 2;
				if ( (diff.x * diff.x) + (diff.y * diff.y) < (sideC * sideC)) {
					clickedBlock = b;
				}
				
			}
		}
		
		return clickedBlock;
	}
	
	public List<Block> getAdjacentMovable(Block origin) {
		//List<Block> possible = getAdjacentOnGrid(origin);
		List<Block> possible = getAdjacentInteractable(origin);
		
		List<Block> movable = new LinkedList<Block>();
		for (Block b : possible) {
			//isn't an open space on the grid
			if ( !BlockMap.getImmovable().contains(b.getType()) ) {
				//no occupant
				if (!b.hasOccupant()) {
					movable.add(b);
				}
			}
		}
		
		return movable;
	}
	
	public List<Block> getAdjacentAttackable(Block origin, GameRound round) {
		//List<Block> possible = getAdjacentOnGrid(origin);
		List<Block> possible = getAdjacentInteractable(origin);
		
		List<Block> occupied = new LinkedList<Block>();
		for (Block b : possible) {
			//has an occupant
			if (b.hasOccupant()) {
				if (!round.currentPlayer.getActors().contains(b.getOccupant())) {
					occupied.add(b);
				}
			}
		}
		
		return occupied;
	}
	
	public List<Block> getAdjacentOccupied(Block origin) {
		//List<Block> possible = getAdjacentOnGrid(origin);
		List<Block> possible = getAdjacentInteractable(origin);
		
		List<Block> occupied = new LinkedList<Block>();
		for (Block b : possible) {
			//has an occupant
			if (b.hasOccupant()) {
				occupied.add(b);
			}
		}
		
		return occupied;
	}
	
}
