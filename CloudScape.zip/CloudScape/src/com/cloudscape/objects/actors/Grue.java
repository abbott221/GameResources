package com.cloudscape.objects.actors;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.cloudscape.objects.Block;
import com.cloudscape.objects.players.Player;

public class Grue extends GameActor {
	//public int health = 10;
	//public int energy;
	
	public Grue(Player user) {
		//super(user, 15, 8, 1, 2, 3, 2);
		super(new GameActorBuilder().owner(user).image(grue)
				.health(15).energy(8, 1, 2).attack(3, 2));
	}
	
	//=================================================
	//GameDrawable stuff
	static Texture grue = new Texture("GrueCropped.png");
	
	public final static int IMAGE_WIDTH = 58;
	public final static int IMAGE_HEIGHT = 71;
	
	
	@Override
	public Vector2 getLowerLeft() {
		Vector2 vector = this.location.getFocalPoint();
		vector.x -= IMAGE_WIDTH / 2;
		
		return vector;
	}
	
	@Override
	public Vector2 getFocalPoint() {
		return this.location.getFocalPoint();
	}
	
	@Override
	public Vector2 getTopCenter() {
		Vector2 vector = getLowerLeft();
		vector.y += IMAGE_HEIGHT;
		vector.x += IMAGE_WIDTH / 2;
		return vector;
	}
	
//	@Override
//	public void drawSelf(SpriteBatch batch) {
//		Vector2 vector = getLowerLeft();
//		batch.draw(grue, vector.x, vector.y);
//	}
}
