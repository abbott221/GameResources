package com.cloudscape.objects.actors.aliens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.actors.GameActorBuilder;
import com.cloudscape.objects.actors.GameActor.ActorState;
import com.cloudscape.objects.players.Player;

public class BeigeAlien extends GameActor {
	//public int health = 10;
	//public int energy;
	
	private Animation walk;
	
	public BeigeAlien(Player user) {
		//super(user, 10, 6, 2, 2, 2, 1);
		super(new GameActorBuilder().owner(user).image(beigeAlien)
				.health(10).energy(6, 2, 2).attack(2, 1));
		
		TextureRegion walkA = new TextureRegion(new Texture("sprites/AlienBeige/alienBiege_walk1.png"));
		TextureRegion walkB = new TextureRegion(new Texture("sprites/AlienBeige/alienBiege_walk2.png"));
		
		walk = new Animation(0.15f, walkA, walkB);
	}
	
	//=================================================
	//GameDrawable stuff
	//static Texture beigeAlien = new Texture("alien_beige.png");
	static Texture beigeAlien = new Texture("sprites/AlienBeige/alienBiege_front.png");
	
	//public final static int IMAGE_WIDTH = 40;
	public final static int IMAGE_WIDTH = (int) (beigeAlien.getWidth() * (58.0f / beigeAlien.getHeight()));
	//public final static int IMAGE_HEIGHT = 66;
	public final static int IMAGE_HEIGHT = 58;
	
	
	@Override
	public Vector2 getLowerLeft() {
		Vector2 vector = this.location.getFocalPoint();
		vector.x -= IMAGE_WIDTH / 2;
		
		return vector;
	}
	
	@Override
	public Vector2 getFocalPoint() {
		return this.location.getFocalPoint();
	}
	
	@Override
	public Vector2 getTopCenter() {
		Vector2 vector = getLowerLeft();
		vector.y += IMAGE_HEIGHT;
		vector.x += IMAGE_WIDTH / 2;
		return vector;
	}
	
	
	@Override
	public int getImageWidth() {
		return IMAGE_WIDTH;
	}
	@Override
	public int getImageHeight() {
		return IMAGE_HEIGHT;
	}
	
	@Override
	public void drawWalk(SpriteBatch batch) {
		Vector2 targetVector = getLowerLeft();
		
		movementTime += Gdx.graphics.getDeltaTime();
		
		Vector2 currentVector = new Vector2(targetVector.x, targetVector.y);
		
		
		float actionLength = 0.5f;
		
		if (movementTime > actionLength) {
			currentVector = targetVector;
			state = ActorState.STAND;
		} else {
			float timeRatio = (actionLength - movementTime) / actionLength;
			
			currentVector.x = originVector.x * (timeRatio) + targetVector.x * (1.0f - timeRatio);
			currentVector.y = originVector.y * (timeRatio) + targetVector.y * (1.0f - timeRatio);
		}
		
		//=======
		
		TextureRegion frame = walk.getKeyFrame(movementTime, true);
		
		batch.draw(frame, currentVector.x, currentVector.y, IMAGE_WIDTH, IMAGE_HEIGHT);
		
		motionVector.x = currentVector.x;
		motionVector.y = currentVector.y;
	}
}
