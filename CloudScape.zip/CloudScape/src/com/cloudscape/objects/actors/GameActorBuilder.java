package com.cloudscape.objects.actors;

import com.badlogic.gdx.graphics.Texture;
import com.cloudscape.objects.players.Player;

public class GameActorBuilder {
	public Player owner;
	public Texture img;
	
	public int health;
	
	public int energy;
	
	public int moveEnergyCost;
	public int attackEnergyCost;
	
	public int attackPower;
	public int attackRange;
	
	public GameActorBuilder health(int maxHealth) {
		this.health = maxHealth;
		return this;
	}
	
	public GameActorBuilder energy(int maxEnergy, int moveCost, int attackCost) {
		this.energy = maxEnergy;
		this.moveEnergyCost = moveCost;
		this.attackEnergyCost = attackCost;
		return this;
	}
	
	public GameActorBuilder attack(int attackPower, int attackRange) {
		this.attackPower = attackPower;
		this.attackRange = attackRange;
		return this;
	}
	
	public GameActorBuilder owner(Player value) {
		this.owner = value;
		return this;
	}
	
	public GameActorBuilder image(Texture value) {
		this.img = value;
		return this;
	}
}