package com.cloudscape.objects.actors;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.cloudscape.objects.Block;
import com.cloudscape.objects.GameDrawable;
import com.cloudscape.objects.Grid;
import com.cloudscape.objects.actors.aliens.BeigeAlien;
import com.cloudscape.objects.actors.aliens.BlueAlien;
import com.cloudscape.objects.actors.aliens.GreenAlien;
import com.cloudscape.objects.actors.aliens.PinkAlien;
import com.cloudscape.objects.actors.aliens.YellowAlien;
import com.cloudscape.objects.players.Player;

public abstract class GameActor implements GameDrawable {
	
	public enum ActorState {
		STAND, WALK, ATTACK, HURT, JUMP
	}
	
	public int healthMax;
	public int healthCurrent;
	
	public int energyMax;
	public int energyCurrent;
	
	public int moveEnergyCost;
	public int attackEnergyCost;
	public int attackPower;
	public int attackRange;
	
	//public boolean inTransit = false;
	public ActorState state = ActorState.STAND;
	protected Vector2 originVector;
	protected float movementTime = 0;
	public Vector2 motionVector = new Vector2(); //track the actor location for the health bar stuff
	
	public Block location;
	
	public Player owner;
	
	public Label ownerDisplay;
	
	Texture img;
	
	//move x distance and attack once, attack energy meta -> vs. move very little but attack much more
	//High move energy, low attack energy, high attack power -> hard to move, but is a tank
	//low move energy, low attack energy -> moves and attacks a ton, is a bird
	//low move energy, high attack energy -> easy to move, but can't attack much per turn
	GameActor(Player user, Texture image, int maxHealth, int maxEnergy, int moveEnergy, int atkEnergy, int atkPower, int atkRange) {
		owner = user;
		img = image;
		
		healthMax = maxHealth;
		healthCurrent = maxHealth;
		energyMax = maxEnergy;
		energyCurrent = maxEnergy;
		
		moveEnergyCost = moveEnergy;
		attackEnergyCost = atkEnergy;
		attackPower = atkPower;
		attackRange = atkRange;
	}
	
	protected GameActor(GameActorBuilder builder) {
		owner = builder.owner;
		img = builder.img;
		
		healthMax = builder.health;
		healthCurrent = builder.health;
		energyMax = builder.energy;
		energyCurrent = builder.energy;
		
		moveEnergyCost = builder.moveEnergyCost;
		attackEnergyCost = builder.attackEnergyCost;
		attackPower = builder.attackPower;
		attackRange = builder.attackRange;
	}
	
	public static GameActor get(String className, Player user) {
		if (className.equalsIgnoreCase("Grue")) {
			return new Grue(user);
		} else if (className.equalsIgnoreCase("Knight")) {
			return new Knight(user);
		} else if (className.equalsIgnoreCase("BeigeAlien")) {
			return new BeigeAlien(user);
		} else if (className.equalsIgnoreCase("BlueAlien")) {
			return new BlueAlien(user);
		} else if (className.equalsIgnoreCase("GreenAlien")) {
			return new GreenAlien(user);
		} else if (className.equalsIgnoreCase("PinkAlien")) {
			return new PinkAlien(user);
		} else if (className.equalsIgnoreCase("YellowAlien")) {
			return new YellowAlien(user);
		}
		return null;
	}
	
	
	
	public void setLocation(Block block) {
		//old location
		if (location != null) {
			location.setOccupant(null);
		}
		//new location
		location = block;
		
		block.setOccupant(this);
	}
	
	public void setLocation(int row, int column) {
		Block b = Grid.getInstance().getBlockAt(row, column);
		this.setLocation(b);
	}
	
	
	
	public void moveTo(Block block) {
		
		if (this.getLocation().height != block.height) {
			//System.out.println("HEIGHT CHANGE");
			state = ActorState.JUMP;
		} else {
			state = ActorState.WALK;
		}
		
		//state = ActorState.WALK;
		originVector = this.getLowerLeft();
		movementTime = 0.0f;
		
		//=======
		
		energyCurrent -= moveEnergyCost;
		
		//old location
		if (location != null) {
			location.setOccupant(null);
		}
		//new location
		location = block;
		
		block.setOccupant(this);
	}
	
	public void moveTo(int row, int column) {
		Block b = Grid.getInstance().getBlockAt(row, column);
		this.moveTo(b);
	}
	
	public void setState(ActorState s) {
		state = s;
		originVector = this.getLowerLeft();
		movementTime = 0.0f;
	}
	
	public void attack(GameActor other) {
		state = ActorState.ATTACK;
		originVector = this.getLowerLeft();
		movementTime = 0.0f;
		
		other.setState(ActorState.HURT);
		
		//=======
		
		other.healthCurrent -= this.attackPower;
		this.energyCurrent -= this.attackEnergyCost;
		
		if (other.healthCurrent <= 0) {
			//other.owner.removeActor(other);
			other.die();
		}
	}
	public void die() {
		owner.removeActor(this);
		this.location.setOccupant(null);
		this.location = null;
		
		if (this.ownerDisplay != null) {
			this.ownerDisplay.remove();
		}
	}
	
	public boolean canAttack() {
		return (this.energyCurrent >= this.attackEnergyCost);
	}
	public boolean canMove() {
		return (this.energyCurrent >= this.moveEnergyCost);
	}
	
	//=================================================
	
	public Block getLocation() {
		return location;
	}
	
	public void drawBars(ShapeRenderer shapeBatch) {
		
		//healthCurrent = 7;
		
		Vector2 top = new Vector2();
		//Vector2 top = this.getTopCenter();
		
		top.x = motionVector.x + (this.getImageWidth() / 2);
		top.y = motionVector.y + this.getImageHeight();
		
		
		float barWidth = 35;
		
		//full health
		shapeBatch.setColor(Color.LIGHT_GRAY);
		shapeBatch.rect(top.x - (barWidth / 2), top.y + 12, barWidth, 5);
		
		
		//part health
		float healthRatio = (float) (healthCurrent * 1.0 / healthMax);
		if (healthRatio < 0.25f) {
			shapeBatch.setColor(Color.RED);
		} else if (healthRatio < 0.5f) {
			shapeBatch.setColor(Color.YELLOW);
		} else {
			shapeBatch.setColor(Color.GREEN);
		}
		//shapeBatch.setColor(Color.GREEN);
		shapeBatch.rect(top.x - (barWidth / 2), top.y + 12, barWidth * ((healthCurrent + 0.0f) / healthMax), 5);
		
		
		
		//full energy
		shapeBatch.setColor(Color.LIGHT_GRAY);
		shapeBatch.rect(top.x - (barWidth / 2), top.y + 5, barWidth, 5);
		//part energy
		shapeBatch.setColor(Color.BLUE);
		shapeBatch.rect(top.x - (barWidth / 2), top.y + 5, barWidth * ((energyCurrent + 0.0f) / energyMax), 5);
	}
	
	
	
	public int getImageHeight() {
		return img.getHeight();
	}
	public int getImageWidth() {
		return img.getWidth();
	}
	
	
	
	@Override
	public void drawSelf(SpriteBatch batch) {
		if (state == ActorState.STAND) {
			drawStand(batch);
		} else if (state == ActorState.WALK) {
			drawWalk(batch);
		} else if (state == ActorState.ATTACK) {
			drawAttack(batch);
		} else if (state == ActorState.HURT) {
			drawHurt(batch);
		} else if (state == ActorState.JUMP) {
			drawJump(batch);
		}
	}
	
	
	
	public void drawStand(SpriteBatch batch) {
		Vector2 targetVector = getLowerLeft();
		batch.draw(img, targetVector.x, targetVector.y, getImageWidth(), getImageHeight());
		
		motionVector.x = targetVector.x;
		motionVector.y = targetVector.y;
	}
	
	public void drawWalk(SpriteBatch batch) {
		Vector2 targetVector = getLowerLeft();
		
		movementTime += Gdx.graphics.getDeltaTime();
		
		Vector2 currentVector = new Vector2(targetVector.x, targetVector.y);
		
		
		float actionLength = 0.5f;
		
		if (movementTime > actionLength) {
			currentVector = targetVector;
			state = ActorState.STAND;
		} else {
			float timeRatio = (actionLength - movementTime) / actionLength;
			
			currentVector.x = originVector.x * (timeRatio) + targetVector.x * (1.0f - timeRatio);
			currentVector.y = originVector.y * (timeRatio) + targetVector.y * (1.0f - timeRatio);
		}
		
		//=======
		
		TextureRegion frame = new TextureRegion(img);
		
		batch.draw(frame, currentVector.x, currentVector.y, getImageWidth(), getImageHeight());
		
		motionVector.x = currentVector.x;
		motionVector.y = currentVector.y;
	}
	
	public void drawAttack(SpriteBatch batch) {
		Vector2 targetVector = getLowerLeft();
		
		movementTime += Gdx.graphics.getDeltaTime();
		
		Vector2 currentVector = new Vector2(targetVector.x, targetVector.y);
		
		
		float actionLength = 0.3f;
		
		if (movementTime > actionLength) {
			currentVector = targetVector;
			state = ActorState.STAND;
		} else {
			currentVector.x = targetVector.x;
			currentVector.y = (float) (targetVector.y + 15.0 * Math.sin((Math.PI * movementTime) / actionLength));
		}
		
		//=======
		
		TextureRegion frame = new TextureRegion(img);
		
		batch.draw(frame, currentVector.x, currentVector.y, getImageWidth(), getImageHeight());
		
		motionVector.x = currentVector.x;
		motionVector.y = currentVector.y;
	}
	
	public void drawHurt(SpriteBatch batch) {
		Vector2 targetVector = getLowerLeft();
		
		movementTime += Gdx.graphics.getDeltaTime();
		
		Vector2 currentVector = new Vector2(targetVector.x, targetVector.y);
		
		
		float actionLength = 0.3f;
		
		if (movementTime > actionLength) {
			currentVector = targetVector;
			state = ActorState.STAND;
		} else {
			//currentVector.x = targetVector.x;
			currentVector.x = (float) (targetVector.x + 8.0 * Math.sin((5.0 * Math.PI * movementTime) / actionLength));
			//currentVector.y = (float) (targetVector.y + 30.0 * Math.sin((Math.PI * movementTime) / actionLength));
			currentVector.y = targetVector.y;
		}
		
		//=======
		
		TextureRegion frame = new TextureRegion(img);
		
		batch.draw(frame, currentVector.x, currentVector.y, getImageWidth(), getImageHeight());
		
		motionVector.x = currentVector.x;
		motionVector.y = currentVector.y;
	}
	
	public void drawJump(SpriteBatch batch) {
		Vector2 targetVector = getLowerLeft();
		
		movementTime += Gdx.graphics.getDeltaTime();
		
		Vector2 currentVector = new Vector2(targetVector.x, targetVector.y);
		
		
		float actionLength = 0.3f;
		//float actionLength = 1.0f;
		
		if (movementTime > actionLength) {
			currentVector = targetVector;
			state = ActorState.STAND;
		} else {
			float timeRatio = (actionLength - movementTime) / actionLength;
			
			currentVector.x = originVector.x * (timeRatio) + targetVector.x * (1.0f - timeRatio);
			currentVector.y = originVector.y * (timeRatio) + targetVector.y * (1.0f - timeRatio);
			currentVector.y += (float) (30.0 * Math.sin(Math.PI * timeRatio));
		}
		
		//=======
		
		TextureRegion frame = new TextureRegion(img);
		
		batch.draw(frame, currentVector.x, currentVector.y, getImageWidth(), getImageHeight());
		
		motionVector.x = currentVector.x;
		motionVector.y = currentVector.y;
	}
}
