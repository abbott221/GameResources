package com.cloudscape.objects.actors;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.cloudscape.objects.Block;
import com.cloudscape.objects.actors.GameActor.ActorState;
import com.cloudscape.objects.players.Player;

public class Knight extends GameActor {
	//public int health = 10;
	//public int energy;
	
	private Animation walk;
	
	public Knight(Player user) {
		//super(user, 15, 8, 1, 2, 3, 1);
		super(new GameActorBuilder().owner(user).image(knight)
				.health(15).energy(8, 1, 2).attack(3, 1));
		
		Texture fullThing = new Texture("sprites/Knight/knight.png");
		
		//TextureRegion[] split = TextureRegion.split(fullThing, 64, 64)[0];
		TextureRegion[][] split = TextureRegion.split(fullThing, 64, 64);
		TextureRegion[] sideWalk = split[11];
		
		walk = new Animation(0.15f, sideWalk[0], sideWalk[1], sideWalk[2], sideWalk[3], sideWalk[4],
				sideWalk[5], sideWalk[6], sideWalk[7], sideWalk[8]);
	}
	
	//=================================================
	//GameDrawable stuff
	static Texture knight = new Texture("knight.png");
	
	public final static int IMAGE_WIDTH = 94;
	public final static int IMAGE_HEIGHT = 80;
	
	
	@Override
	public Vector2 getLowerLeft() {
		Vector2 vector = this.location.getFocalPoint();
		vector.x -= IMAGE_WIDTH / 2;
		
		return vector;
	}
	
	@Override
	public Vector2 getFocalPoint() {
		return this.location.getFocalPoint();
	}
	
	@Override
	public Vector2 getTopCenter() {
		Vector2 vector = getLowerLeft();
		vector.y += IMAGE_HEIGHT;
		vector.x += IMAGE_WIDTH / 2;
		return vector;
	}
	
	@Override
	public void drawWalk(SpriteBatch batch) {
		Vector2 targetVector = getLowerLeft();
		
		movementTime += Gdx.graphics.getDeltaTime();
		
		Vector2 currentVector = new Vector2(targetVector.x, targetVector.y);
		
		
		float actionLength = 0.5f;
		
		if (movementTime > actionLength) {
			currentVector = targetVector;
			state = ActorState.STAND;
		} else {
			float timeRatio = (actionLength - movementTime) / actionLength;
			
			currentVector.x = originVector.x * (timeRatio) + targetVector.x * (1.0f - timeRatio);
			currentVector.y = originVector.y * (timeRatio) + targetVector.y * (1.0f - timeRatio);
		}
		
		//=======
		
		TextureRegion frame = walk.getKeyFrame(movementTime, true);
		
		batch.draw(frame, currentVector.x, currentVector.y, IMAGE_WIDTH, IMAGE_HEIGHT);
		
		motionVector.x = currentVector.x;
		motionVector.y = currentVector.y;
	}
}





