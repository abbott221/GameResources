package com.cloudscape.objects;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.cloudscape.BlockMap;
import com.cloudscape.Commons;
import com.cloudscape.DeviceScreen;
import com.cloudscape.objects.actors.GameActor;

public class Block implements GameDrawable {
	
	public enum BlockState {
		SELECT, MOVE, ATTACK
	}
	
	
	//less than 24, possibly more than 20
	private static final int HEIGHT_SPACING = 22;
	
	
//	public enum BlockType {
//		GRASS, DIRT, WATER, NONE;
//	}
	
	//private BlockType myType;
	private BlockMap.TypeName myType = BlockMap.TypeName.NONE;
	private BlockState myState = null;
	
	private GameActor occupant = null;
	
	private boolean inTransit = false;
	
	public int row;
	public int column;
	//then, use x and y for pixel coordinates
	
	public int height = 1;
	
//	public Block() {
//		myType = BlockType.NONE;
//	}
	public Block(int r, int c) {
		row = r;
		column = c;
	}
	
	public Block(int r, int c, int h) {
		row = r;
		column = c;
		height = h;
	}
	
	
	/*
	 * Occupant methods
	 */
	public GameActor getOccupant() {
		return occupant;
	}
	public void setOccupant(GameActor newOcc) {
		occupant = newOcc;
	}
	public boolean hasOccupant() {
		return (occupant != null);
	}
	
	
	public BlockMap.TypeName getType() {
		return myType;
	}
	public void setType(BlockMap.TypeName type) {
		myType = type;
	}
	public void setType(String type) {
		myType = BlockMap.getInstance().getTypeByXML(type).getEnumName();
	}
	
	public BlockState getState() {
		return myState;
	}
	public void setState(BlockState state) {
		myState = state;
	}
	
	//=================================================
	//GameDrawable stuff
//	Texture grass = new Texture("demo_grass.png");
//	Texture dirt = new Texture("demo_dirt.png");
	
	//these are not the actual dimensions of the image; these are distorted for the staggered drawing of the blocks
	public final static int STAGGERED_WIDTH = 65;
	public final static int STAGGERED_HEIGHT = 52;
	
	public final static int IMAGE_WIDTH = 65;
	public final static int IMAGE_HEIGHT = 89;
	
	public final static int FOCAL_HEIGHT = IMAGE_HEIGHT - (IMAGE_WIDTH / 2);
	
	
	@Override
	public void drawSelf(SpriteBatch batch) {
		Vector2 blockPoint = getLowerLeft();
		
		if (this.getType() == BlockMap.TypeName.NONE) {
			//
		} else {
			Texture texturePath = BlockMap.getInstance().getTypeByEnum(this.getType()).getTexture();
			batch.draw(texturePath, blockPoint.x, blockPoint.y);
			
			if (height > 1) {
				for (int i = 0; i < height; i++) {
					batch.draw(texturePath, blockPoint.x, blockPoint.y + HEIGHT_SPACING*i);
				}
			}
		}
	}
	
	public void drawActiveState(ShapeRenderer shapeBatch) {
		
		
		
		if (this.myState == BlockState.SELECT) {
			//blue
			//shapeBatch.setColor(0, 0, 1, 0.3f);
			shapeBatch.setColor(0, 0, 1, 1.0f);
		}
		if (this.myState == BlockState.MOVE) {
			//yellow
			//shapeBatch.setColor(1, 1, 0, 0.3f);
			shapeBatch.setColor(1, 1, 0, 1.0f);
		}
		if (this.myState == BlockState.ATTACK) {
			//red
			//shapeBatch.setColor(1, 0, 0, 0.3f);
			shapeBatch.setColor(1, 0, 0, 1.0f);
		}
		//shapeBatch.setColor(0, 0, 1, 0.3f);
		Vector2 center = this.getFocalPoint();
		
		/*
		 * Transparent Ellipses
		 */
		
//		//shapeBatch.circle(center.x, center.y, Block.IMAGE_WIDTH / 2); //~32, 32
//		shapeBatch.ellipse(center.x - 32, center.y - 32, 63, 60); // width, height
		
		/*
		 * Solid hexagons
		 */
		
		float halfWidth = STAGGERED_WIDTH / 2.0f;
		
		Vector2 topRight = new Vector2(center.x + halfWidth, center.y + 16.0f);
		Vector2 top = new Vector2(center.x, center.y + 33.0f);
		Vector2 topLeft = new Vector2(center.x - halfWidth, center.y + 16.0f);
		
		Vector2 bottomRight = new Vector2(center.x + halfWidth, center.y - 19.0f);
		Vector2 bottom = new Vector2(center.x, center.y - 35.0f);
		Vector2 bottomLeft = new Vector2(center.x - halfWidth, center.y - 19.0f);
		
		shapeBatch.triangle(center.x, center.y, topRight.x, topRight.y, top.x, top.y);
		shapeBatch.triangle(center.x, center.y, top.x, top.y, topLeft.x, topLeft.y);
		shapeBatch.triangle(center.x, center.y, topLeft.x, topLeft.y, bottomLeft.x, bottomLeft.y);
		shapeBatch.triangle(center.x, center.y, bottomLeft.x, bottomLeft.y, bottom.x, bottom.y);
		shapeBatch.triangle(center.x, center.y, bottom.x, bottom.y, bottomRight.x, bottomRight.y);
		shapeBatch.triangle(center.x, center.y, bottomRight.x, bottomRight.y, topRight.x, topRight.y);
	}
	
	public void drawOutline(ShapeRenderer shapeBatch) {
		Vector2 center = this.getFocalPoint();
		
		float halfWidth = STAGGERED_WIDTH / 2.0f;
		
		Vector2 topRight = new Vector2(center.x + halfWidth, center.y + 16.0f);
		Vector2 top = new Vector2(center.x, center.y + 33.0f);
		Vector2 topLeft = new Vector2(center.x - halfWidth, center.y + 16.0f);
		
		Vector2 bottomRight = new Vector2(center.x + halfWidth, center.y - 19.0f);
		Vector2 bottom = new Vector2(center.x, center.y - 35.0f);
		Vector2 bottomLeft = new Vector2(center.x - halfWidth, center.y - 19.0f);
		
		//float strokeSize = 3.0f;
		float strokeSize = 1.8f;
		//float strokeSize = 1.0f;
		//float strokeSize = 0.5f;
		//float strokeSize = 0.2f;
		
		shapeBatch.rectLine(topRight, top, strokeSize);
		shapeBatch.rectLine(top, topLeft, strokeSize);
		shapeBatch.rectLine(topLeft, bottomLeft, strokeSize);
		shapeBatch.rectLine(bottomLeft, bottom, strokeSize);
		shapeBatch.rectLine(bottom, bottomRight, strokeSize);
		shapeBatch.rectLine(bottomRight, topRight, strokeSize);
	}
	
	@Override
	public Vector2 getLowerLeft() {
		float x = DeviceScreen.displacement.x + (STAGGERED_WIDTH*this.column);
		float y = DeviceScreen.displacement.y - (STAGGERED_HEIGHT*this.row);
		
		if (this.row % 2 == 1) {
			x += STAGGERED_WIDTH / 2;
		}
		
		return new Vector2(x, y);
	}
	
	@Override
	public Vector2 getTopCenter() {
		Vector2 vector = getLowerLeft();
		vector.y += IMAGE_HEIGHT;
		vector.x += IMAGE_WIDTH / 2;
		return vector;
	}
	
	@Override
	public Vector2 getFocalPoint() {
		Vector2 ll = getLowerLeft();
		ll.x += STAGGERED_WIDTH / 2;
		ll.y += FOCAL_HEIGHT;
		
		if (height > 1) {
			ll.y += HEIGHT_SPACING*(height - 1);
		}
		
		return ll;
	}
}
