package com.cloudscape.objects;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

public interface GameDrawable {
	
	public Vector2 getLowerLeft();
	
	public Vector2 getFocalPoint();
	
	public Vector2 getTopCenter();
	
	public void drawSelf(SpriteBatch batch);
}
