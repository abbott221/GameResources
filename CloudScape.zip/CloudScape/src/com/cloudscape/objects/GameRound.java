package com.cloudscape.objects;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import com.cloudscape.BlockMap;
import com.cloudscape.gui.gamescreen.GameScreenHUD;
import com.cloudscape.objects.Block.BlockState;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.players.Player;

//TODO make singleton as well?
public class GameRound {
	
	List<Player> players;
	public Player currentPlayer;
	
	public List<Block> activeBlocks = new LinkedList<Block>();
	public Block selected = null;
	
	
	public GameRound(List<Player> pList) {
		players = pList;
		currentPlayer = players.get(0);
		
		//currentPlayer.turnStart(this);
		
		//Grid.getInstance().generateMap(xmlMap, isFileName);
	}
	
	public void endTurn() {
		int newIndex = players.indexOf(currentPlayer) + 1;
		if (newIndex == players.size()) {
			newIndex = 0;
		}
		
		currentPlayer.turnEnd(this);
		currentPlayer = players.get(newIndex);
		GameScreenHUD.updateCurrentPlayer();
		
		if (!gameWon()) {
			currentPlayer.turnStart(this); //an NPC will perform BFS logic in this method
		}
		
		//TODO there could be an "energy recharge rate"
		for (GameActor actr : currentPlayer.getActors()) {
			actr.energyCurrent = actr.energyMax;
		}
		
		this.unSelection();
	}
	
	public List<Player> getPlayers() {
		return players;
	}
	
	
	
	public void blockClicked(Block clickedBlock) {
		Grid gr = Grid.getInstance();
		
		//DESELECTION ACTIONS
		//if selecting a selected block, deselect
		if (this.getBlocksByState(BlockState.SELECT).contains(clickedBlock)) {
			unSelection();
		}
		//if selecting off grid or no block, deselect
		else if (clickedBlock == null) {
			unSelection();
		}
		//if selecting empty block, deselect
		else if (clickedBlock.getType() == BlockMap.TypeName.NONE) {
			unSelection();
		}
		//OTHER ACTIONS
		else {
			if (this.getBlocksFromActiveList().contains(clickedBlock)) {
				performAction(clickedBlock);
			} else {
				newSelection(clickedBlock);
			}
			//newSelection(clickedBlock);
		}
	}
	
	public boolean gameWon() {
		int livePlayerCount = 0;
		Player winnerCandidate = null;
		
		for (Player p : this.players) {
			if (p.getActors().size() > 0) {
				livePlayerCount++;
				winnerCandidate = p;
			}
		}
		
		if (livePlayerCount == 1) {
			return true;
		}
		
		return false;
	}
	
	private void checkGameWin() {
		//boolean firstLivePlayerFound = false;
		//boolean secondLivePlayerFound = false;
		int livePlayerCount = 0;
		Player winnerCandidate = null;
		
		for (Player p : this.players) {
			if (p.getActors().size() > 0) {
				livePlayerCount++;
				winnerCandidate = p;
			}
		}
		
		if (livePlayerCount == 1) {
			GameScreenHUD.gameEnd(winnerCandidate);
		}
	}
	
	//=================================================
	//things that can happen from a block click
	private void performAction(Block block) {
		Block active = this.getActiveBlockFromBlock(block);
		if (active.getState() == BlockState.MOVE) {
			//move the occupant from the selected block to the clicked ActiveBlock
			this.getBlocksByState(BlockState.SELECT).get(0).getOccupant().moveTo(block);
			newSelection(block);
		}
		else if (active.getState() == BlockState.ATTACK) {
			this.getBlocksByState(BlockState.SELECT).get(0).getOccupant().attack(block.getOccupant());
			unSelection();
		}
		
		//check for game win here
		checkGameWin();
	}
	
	private void newSelection(Block newSelect) {
		unSelection(); //clear activeBlocks
		Grid gr = Grid.getInstance();
		
		this.selected = newSelect;
		if (this.selected.hasOccupant()) {
			GameScreenHUD.addActorInfoLabel();
		}
		
		
		addActiveBlock(BlockState.SELECT, newSelect);
		
		if (newSelect.hasOccupant()) {
			//if it belongs to the current player, then the current player can do stuff with it
			if (currentPlayer.getActors().contains(newSelect.getOccupant())) {
				//what can my actor do?
				
				if (newSelect.getOccupant().canMove()) {
					for (Block b : gr.getAdjacentMovable(newSelect)) {
						addActiveBlock(BlockState.MOVE, b);
					}
				}
				if (newSelect.getOccupant().canAttack()) {
					Set<Block> withinRange = new HashSet<Block>();
					withinRange.add(newSelect);
					
					for (int i = 0; i < newSelect.getOccupant().attackRange; i++) {
						Set<Block> adjList = new HashSet<Block>();
						for (Block b : withinRange) {
							adjList.addAll(gr.getAdjacentOnGrid(b));
							//adjList.addAll(gr.getAdjacentAttackable(b, this));
						}
						withinRange.addAll(adjList);
					}
					
					List<Block> inRange = new LinkedList<Block>(withinRange);
					gr.inRangeFilter(newSelect, inRange);
					
					List<Block> attackable = new LinkedList<Block>();
					//for (Block b : withinRange) {
					for (Block b : inRange) {
						if (b.hasOccupant() && b.getOccupant().owner != currentPlayer) {
							attackable.add(b);
						}
					}
					
					for (Block b : attackable) {
						addActiveBlock(BlockState.ATTACK, b);
					}
					
//					for (Block b : gr.getAdjacentAttackable(newSelect, this)) {
//						addActiveBlock(BlockState.ATTACK, b);
//					}
				}
				
				
			}
		}
	}
	
	private void unSelection() {
		GameScreenHUD.removeActorInfoLabel();
		this.selected = null;
		this.activeBlocks = new LinkedList<Block>();
	}
	
	//=================================================
	//activeBlocks stuff
	public List<Block> getBlocksByState(BlockState state) {
		List<Block> list = new LinkedList<Block>();
		for (Block ab : activeBlocks) {
			if (ab.getState() == state) {
				list.add(ab);
			}
		}
		return list;
	}
	private List<Block> getBlocksFromActiveList() {
		List<Block> list = new LinkedList<Block>();
		for (Block ab : activeBlocks) {
			list.add(ab);
		}
		return list;
	}
	private void addActiveBlock(BlockState state, Block block) {
		block.setState(state);
		this.activeBlocks.add(block);
	}
	private Block getActiveBlockFromBlock(Block block) {
		Block active = null;
		for (Block ab : activeBlocks) {
			if (ab == block) {
				active = ab;
			}
		}
		return active;
	}
}
