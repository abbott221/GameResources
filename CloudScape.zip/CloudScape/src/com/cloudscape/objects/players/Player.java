package com.cloudscape.objects.players;
import java.util.LinkedList;
import java.util.List;

import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.actors.GameActor;

public class Player {
	List<GameActor> actors = new LinkedList<GameActor>();
	
	//TODO make this not public later? possibly make a toString method?
	public String username;
	
	
	public boolean isNPC = false;
	
	
	public int maxTeamHealth = 1;
	
	//turnEnd(), onTurn()???
	
	
	public Player(String name) {
		username = name;
	}
	
	public void addActor(GameActor actr) {
		actors.add(actr);
		
		maxTeamHealth = 0;
		for (GameActor actor : getActors()) {
			maxTeamHealth += actor.healthMax;
		}
	}
	public GameActor getActor(int index) {
		return actors.get(index);
	}
	public void removeActor(GameActor actr) {
		actors.remove(actr);
	}
	public List<GameActor> getActors() {
		return actors;
	}
	
	
	public void turnStart(GameRound round) {
		//change display settings to enable the player's turn
	}
	public void turnEnd(GameRound round) {
		//change display settings to disable the player's turn
	}
}
