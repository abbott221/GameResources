package com.cloudscape.objects.players;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

import com.cloudscape.Commons;
import com.cloudscape.objects.Block;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.Grid;
import com.cloudscape.objects.Block.BlockState;
import com.cloudscape.objects.actors.GameActor;

public class NPC extends Player {
	
	private class RunTurn implements Runnable {
		GameRound round;
		NPC npc;
		Thread thread;
		
		boolean keepGoing = true;
		int moveCount = 0;
		
		RunTurn(GameRound r, NPC n, Thread t) {
			round = r;
			npc = n;
			thread = t;
		}
		@Override
		public void run() {
			Commons.npcLock.lock();
			
			for (GameActor actor : npc.getActors()) {
				keepGoing = true;
				briefPause();
				round.blockClicked(actor.location);
				
				while (round.activeBlocks.size() > 1 && keepGoing) {
					briefPause();
					doSomething(actor);
				}
				//keepGoing = true;
			}
			briefPause();
			round.endTurn();
			
			Commons.npcLock.unlock();
		}
		
		private void doSomething(GameActor actor) {
			if (round.getBlocksByState(BlockState.ATTACK).size() > 0) {
				round.blockClicked(round.getBlocksByState(BlockState.ATTACK).get(0));
				
				briefPause();
				//unSelection() is called after an attack
				round.blockClicked(actor.location);
			}
			else if (round.getBlocksByState(BlockState.MOVE).size() > 0) {
				
				Map<Block, Block> childToParent = new HashMap<>();
				
				Grid gr = Grid.getInstance();
				
				//=======
				
				Set<Block> searchRange = new HashSet<Block>();
				searchRange.add(actor.location);
				
				boolean growthObserved = true;
				
				int maxRange = 5;
				int rangeCount = 0;
				
				do {
					rangeCount++;
					
					Set<Block> adjRing = new HashSet<Block>();
					for (Block parent : searchRange) {
						Set<Block> adjList = new HashSet<Block>();
						adjList.addAll(gr.getAdjacentMovable(parent));
						adjList.addAll(gr.getAdjacentAttackable(parent, round));
						for (Block childCandidate : adjList) {
							if (!searchRange.contains(childCandidate)) {
								childToParent.put(childCandidate, parent);
							}
						}
						adjRing.addAll(adjList);
					}
					adjRing.removeAll(searchRange);
					
					if (adjRing.size() == 0) {
						growthObserved = false;
					}
					
					searchRange.addAll(adjRing);
					
					
					if (rangeCount == maxRange) {
						growthObserved = false;
					}
				} while (growthObserved && getAttackable(searchRange) == null);
				
				//if growthObserved, then there is an attackable
				if (growthObserved) {
					Block goHere = getAttackable(searchRange);
					Stack<Block> path = new Stack<Block>();
					path.push(goHere);
					while (childToParent.containsKey(goHere)) {
						Block fromHere = childToParent.get(goHere);
						path.push(fromHere);
						goHere = fromHere;
					}
					//remove the current location, which would result in unselection
					//path.pop();
					Block nextMove = path.pop();
					while (!path.isEmpty() && actor.canMove()) {
						nextMove = path.pop();
						briefPause();
						round.blockClicked(gr.getBlockAt(nextMove.row, nextMove.column));
					}
					while (actor.canAttack()) {
						briefPause();
						round.blockClicked(actor.location);
						briefPause();
						round.blockClicked(gr.getBlockAt(nextMove.row, nextMove.column));
					}
				} else {
					//random move
					//System.out.println("RANDOM MOVE");
					//round.blockClicked(round.getBlocksByState(BlockState.MOVE).get(0));
					keepGoing = false;
				}
			}
		}
		
		private Block getAttackable(Set<Block> bSet) {
			Block result = null;
			for (Block b : bSet) {
				if (isAttackable(b)) {
					result = b;
				}
			}
			return result;
		}
		
		private boolean isAttackable(Block b) {
			if (b.hasOccupant()) {
				if (!round.currentPlayer.getActors().contains(b.getOccupant())) {
					return true;
				}
			}
			return false;
		}
		
		private void briefPause() {
			try {
				//System.gc();
				Commons.npcLock.unlock();
				Thread.sleep(600);
				
				if (round.gameWon()) {
					thread.join();
					//thread.stop();
				}
				
				Commons.npcLock.lock();
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public NPC() {
		super("NPC");
		isNPC = true;
	}
	
	public NPC(String name) {
		super(name);
		isNPC = true;
	}
	
	@Override
	public void turnStart(GameRound round) {
		Thread thread = null;
		thread = new Thread(new RunTurn(round, this, thread));
		thread.start();
	}
	
	@Override
	public void turnEnd(GameRound round) {
		//possibly do nothing here?
	}
}
