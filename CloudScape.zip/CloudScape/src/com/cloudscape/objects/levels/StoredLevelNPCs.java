package com.cloudscape.objects.levels;

import java.util.LinkedList;
import java.util.List;

import com.cloudscape.gui.GameClass;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.Grid;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.actors.Knight;
import com.cloudscape.objects.actors.aliens.BeigeAlien;
import com.cloudscape.objects.players.NPC;
import com.cloudscape.objects.players.Player;

public class StoredLevelNPCs extends Level {
	
	private String filename;
	
	public StoredLevelNPCs(String xmlFile) {
		filename = xmlFile;
	}
	
	@Override
	public GameRound makeLevel() {
		List<Player> users = new LinkedList<Player>();
		users.add(new NPC("NPC 1"));
		users.add(new NPC("NPC 2"));
		
		GameRound round = new GameRound(users);
		this.generateMap(users, filename, false);
		
		//=====
		
		for (Player p : round.getPlayers()) {
			for (GameActor ga : p.getActors()) {
				ga.energyCurrent = ga.energyMax;
				ga.healthCurrent = ga.healthMax;
			}
		}
		
		return round;
	}
}
