package com.cloudscape.objects.levels;

import java.io.IOException;
import java.io.StringWriter;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.XmlReader;
import com.badlogic.gdx.utils.XmlReader.Element;
import com.badlogic.gdx.utils.XmlWriter;
import com.cloudscape.objects.Block;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.Grid;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.actors.aliens.BeigeAlien;
import com.cloudscape.objects.players.Player;

public abstract class Level {
	/**
	 * make the level and generate the map
	 * generateMap() is called
	 * @return the GameRound object
	 */
	public abstract GameRound makeLevel();
	
	public void generateMap(List<Player> users, String xml, boolean isFileName) {
		Grid g = Grid.getInstance();
		
		try {
			Element mapNode;
			XmlReader reader = new XmlReader();
			if (isFileName) {
				FileHandle handle = Gdx.files.internal(xml);
				mapNode = reader.parse(handle);
			} else {
				mapNode = reader.parse(xml);
			}
			
			int rowCount = Integer.parseInt(mapNode.getAttribute("rowCount"));
			int colCount = Integer.parseInt(mapNode.getAttribute("columnCount"));
			
			g.blocks = new Block[rowCount][colCount];
			
			//TODO I could just leave those as null, instead of doing NONE blocktype
			for (int i = 0; i < rowCount; i++) {
				for (int j = 0; j < colCount; j++) {
					g.blocks[i][j] = new Block(i, j);
				}
			}
			
			
			Array<Element> rowNodes = mapNode.getChildrenByNameRecursively("row");
			for (int rCounter = 0; rCounter < rowNodes.size; rCounter++) {
				Element rowNode = rowNodes.get(rCounter);
				
				int rowIndex = Integer.parseInt(rowNode.getAttribute("index"));
				
				Array<Element> columnNodes = rowNode.getChildrenByNameRecursively("column");
				for (int cCounter = 0; cCounter < columnNodes.size; cCounter++) {
					Element columnNode = columnNodes.get(cCounter);
					
					int columnIndex = Integer.parseInt(columnNode.getAttribute("index"));
					
					String heightString = columnNode.getAttribute("height","none");
					if (!heightString.equals("none")) {
						g.blocks[rowIndex][columnIndex].height = Integer.parseInt(heightString);
					}
					
					//===========
					String blockType = columnNode.getText();
					g.blocks[rowIndex][columnIndex].setType(blockType.trim());
				}
				
			}
			
			
			
			Array<Element> playerNodes = mapNode.getChildrenByNameRecursively("player");
			for (int pCounter = 0; pCounter < playerNodes.size; pCounter++) {
				Element playerNode = playerNodes.get(pCounter);
				
				int playerIndex = Integer.parseInt(playerNode.getAttribute("index"));
				
				Array<Element> spawnNodes = playerNode.getChildrenByNameRecursively("spawn");
				for (int sCounter = 0; sCounter < spawnNodes.size; sCounter++) {
					Element spawnNode = spawnNodes.get(sCounter);
					
					int rowIndex = Integer.parseInt(spawnNode.getAttribute("row"));
					int columnIndex = Integer.parseInt(spawnNode.getAttribute("column"));
					String occupant = spawnNode.getAttribute("actor");
					
					//=======
					
					Player user = users.get(playerIndex);
					//GameActor actor = new BeigeAlien(user);
					GameActor actor = GameActor.get(occupant, user);
					user.addActor(actor);
					//actor.moveTo(rowIndex, columnIndex);
					actor.setLocation(rowIndex, columnIndex);
				}
			}
			
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	
	public static String printXML(GameRound map) {
		//System.out.println("XML goes here");
		
		Grid g = Grid.getInstance();
		
		StringWriter writer = new StringWriter();
		XmlWriter xml = new XmlWriter(writer);
		
		try {
			XmlWriter mapNode = xml.element("map")
				.attribute("rowCount", g.getRowCount())
				.attribute("columnCount", g.getColumnCount());
			
			for (int i = 0; i < g.getRowCount(); i++) {
				XmlWriter rowNode = mapNode.element("row")
					.attribute("index", i);
				
				for (int j = 0; j < g.getColumnCount(); j++) {
					rowNode.element("column")
						.attribute("index", j)
						.attribute("height", g.getBlockAt(i, j).height)
						.text(g.getBlockAt(i, j).getType().toString().toLowerCase())
					.pop();
				}
				
				rowNode.pop();
			}
			
			for (int i = 0; i < map.getPlayers().size(); i++) {
				Player p = map.getPlayers().get(i);
				
				XmlWriter playerNode = mapNode.element("player")
					.attribute("index", i);
				
				for (GameActor actor : p.getActors()) {
					playerNode.element("spawn")
						.attribute("row", actor.location.row)
						.attribute("column", actor.location.column)
						.attribute("actor", actor.getClass().getSimpleName().toString())
					.pop();
				}
				
				playerNode.pop();
			}
			
			
			
			
			mapNode.pop();
			
			//System.out.println(writer);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return writer.toString();
	}
	
	
	
}
