package com.cloudscape.objects.levels;

import java.util.LinkedList;
import java.util.List;

import com.cloudscape.gui.GameClass;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.Grid;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.actors.Knight;
import com.cloudscape.objects.actors.aliens.BeigeAlien;
import com.cloudscape.objects.players.NPC;
import com.cloudscape.objects.players.Player;

public class Level2 extends Level {
	@Override
	public GameRound makeLevel() {
		List<Player> users = new LinkedList<Player>();
		users.add(new Player(GameClass.getInstance().username));
		users.add(new NPC());
		
		GameRound round = new GameRound(users);
		this.generateMap(users, "levels/level2.xml", true);
		
		//=====
		
		for (Player p : round.getPlayers()) {
			for (GameActor ga : p.getActors()) {
				ga.energyCurrent = ga.energyMax;
				ga.healthCurrent = ga.healthMax;
			}
		}
		
		return round;
	}
}
