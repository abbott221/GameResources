package com.cloudscape.objects.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.cloudscape.DeviceScreen;
import com.cloudscape.objects.Block;
import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.Grid;

//extends InputAdapter
//implements InputProcessor
public class BlockSelectListener extends InputAdapter {
	
	Vector3 newestPoint = new Vector3();
	Vector3 previousPoint = new Vector3(-1, -1, -1);
	Vector3 sum = new Vector3(0, 0, 0);
	float sumR2 = 0;
	
	GameRound round;
	
	//to filter clicks from drags
	boolean easyClickCandidate;
	
	public BlockSelectListener (GameRound r) {
		round = r;
	}
	
	@Override
	public boolean touchDown(int x, int y, int pointer, int button) {
		sum = new Vector3(0, 0, 0);
		sumR2 = 0;
		
		//=======
		
		//System.out.println("RESET");
		easyClickCandidate = true;
		return false;
	}
	
	@Override
	public boolean touchDragged (int x, int y, int pointer) {
		newestPoint.set(x, y, 0);
		
		x /= DeviceScreen.scale;
		y /= DeviceScreen.scale;
		
		//if last has changed
		if (!(previousPoint.x == -1 && previousPoint.y == -1 && previousPoint.z == -1)) {
			sum.x += Math.abs(newestPoint.x - previousPoint.x);
			sum.y += Math.abs(newestPoint.y - previousPoint.y);
			sumR2 += Math.sqrt(sum.x * sum.x + sum.y + sum.y);
		}
		
		previousPoint.set(x, y, 0);
		
		//=======
		
		//System.out.println("DRAGGED");
		easyClickCandidate = false;
		return false;
	}
	
	@Override
	public boolean touchUp (int x, int y, int pointer, int button) {
		previousPoint.set(-1, -1, -1);
		
		//=======
		
		y = Gdx.graphics.getHeight() - y;
		
		x /= DeviceScreen.scale;
		y /= DeviceScreen.scale;
		
		if (easyClickCandidate) {
			validClick(x, y);
		} else {
			//System.out.println("NOT A CLICK");
			
			//0.5f or 5.0f is the drag threshold, lots of 0s, some 1.14s, and a 3.14ish
			if (sumR2 < 5.0f) {
				System.out.println("BARELY A CLICK " + sumR2);
				validClick(x, y);
			} else {
				System.out.println("NOT A CLICK " + sumR2);
			}
		}
		
		return false;
	}
	
	private void validClick(int x, int y) {
		Grid gr = Grid.getInstance();
		Block clickedBlock = gr.getClosestBlock(x, y);
		if (!round.currentPlayer.isNPC) {
			round.blockClicked(clickedBlock);
		}
	}
}