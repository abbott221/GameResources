package com.cloudscape.objects.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.math.Vector3;
import com.cloudscape.DeviceScreen;

public class ScrollController extends InputAdapter {
	
	Vector3 lastPoint = new Vector3(-1, -1, -1);
	
	public ScrollController () {
		//
	}
	
	//keep track of current location for the center of the zoom
	public boolean mouseMoved (int x, int y) {
		lastPoint.set(x, y, 0);
		return false;
	}
	
	public boolean scrolled (int amount) {
		if (amount == 1) {
			DeviceScreen.scale /= 1.03f;
			DeviceScreen.displacement.scl(1.03f);
		}
		else if (amount == -1) {
			DeviceScreen.scale *= 1.03f;
			DeviceScreen.displacement.scl(1.0f / 1.03f);
		}
		
		return false;
	}
}