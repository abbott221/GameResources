package com.cloudscape.objects.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.math.Vector3;
import com.cloudscape.DeviceScreen;

public class DragController extends InputAdapter {
	
	//the newest recorded point
	Vector3 newestPoint = new Vector3();
	//the last recorded point (previous)
	Vector3 previousPoint = new Vector3(-1, -1, -1);
	//cumulative of difference between last and current
	//public Vector3 displacement = new Vector3();
	
	public DragController () {
		//
	}
	
	@Override
	public boolean touchDragged (int x, int y, int pointer) {
		x /= DeviceScreen.scale;
		y /= DeviceScreen.scale;
		
		//http://stackoverflow.com/questions/7708379/changing-the-coordinate-system-in-libgdx-java
		y = Gdx.graphics.getHeight() - y;
		
		newestPoint.set(x, y, 0);
		
		//if last has changed
		if (!(previousPoint.x == -1 && previousPoint.y == -1 && previousPoint.z == -1)) {
			//delta is (last - curr)
			//displacement.x += previousPoint.x - newestPoint.x;
			DeviceScreen.displacement.x += newestPoint.x - previousPoint.x;
			DeviceScreen.displacement.y += newestPoint.y - previousPoint.y;
		}
		previousPoint.set(x, y, 0);
		return false;
	}
	
	@Override
	public boolean touchUp (int x, int y, int pointer, int button) {
		previousPoint.set(-1, -1, -1);
		return false;
	}
}