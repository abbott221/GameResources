package com.cloudscape.objects;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.xml.bind.DatatypeConverter;

public class NetworkingStuff {
	
	private String username;
	private String password;
	
	private String requestHelper(String targetURL, String requestMethod, String query) {
		String output = null;
		
		try {
			URL url = new URL(targetURL);
			
			String authString = username + ":" + password;
			String encoding = DatatypeConverter.printBase64Binary(authString.getBytes("UTF-8"));
			
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod(requestMethod);
			conn.setRequestProperty("Content-Type", "application/xml");
			conn.setRequestProperty("Accept", "application/xml");
			conn.setRequestProperty("Authorization", "Basic " + encoding);
			
			//===================================
			
			conn.setDoOutput(true);
			conn.setAllowUserInteraction(false);
			
			PrintStream ps = new PrintStream(conn.getOutputStream());
			ps.print(query);
			ps.close();
			
			//===================================
			
			//if (conn.getResponseCode() != 200) {
			if (conn.getResponseCode() > 250) {
				System.out.println(conn.getResponseCode());
				System.out.println(conn.getResponseMessage());
				
				System.out.println("IOException thrown");
				System.out.println(query);
				
				throw new IOException(conn.getResponseMessage());
			}
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			StringBuilder builder = new StringBuilder();
			String line;
			
			line = reader.readLine();
			while (line != null) {
				builder.append(line);
				line = reader.readLine();
			}
			
			reader.close();
			conn.disconnect();
			
			//Commons.printDocument(builder.toString());
			output = builder.toString();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		return output;
	}
	
	
	
	
	//getAllStories
	/**
	 * returns the output from the request in the form of a String
	 */
	private String requestHelper(String targetURL, String requestMethod) {
		String output = null;
		
		try {
			URL url = new URL(targetURL);
			
			String authString = username + ":" + password;
			String encoding = DatatypeConverter.printBase64Binary(authString.getBytes("UTF-8"));
			
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod(requestMethod);
			conn.setRequestProperty("Content-Type", "application/xml");
			conn.setRequestProperty("Accept", "application/xml");
			conn.setRequestProperty("Authorization", "Basic " + encoding);
			
			//if (conn.getResponseCode() != 200) {
			if (conn.getResponseCode() > 250) {
				System.out.println(conn.getResponseCode());
				System.out.println(conn.getResponseMessage());
				
				System.out.println("IOException thrown");
				System.out.println(requestMethod + " " + targetURL);
				
				throw new IOException(conn.getResponseMessage());
			}
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			StringBuilder builder = new StringBuilder();
			String line;
			
			line = reader.readLine();
			while (line != null) {
				builder.append(line);
				line = reader.readLine();
			}
			
			reader.close();
			conn.disconnect();
			
			//Commons.printDocument(builder.toString());
			output = builder.toString();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		return output;
	}
	
	
	private String requestHelperJSON(String targetURL, String requestMethod, String query) {
		String output = null;
		
		try {
			URL url = new URL(targetURL);
			
			String authString = username + ":" + password;
			String encoding = DatatypeConverter.printBase64Binary(authString.getBytes("UTF-8"));
			
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod(requestMethod);
			conn.setRequestProperty("Content-Type", "text/json");
			conn.setRequestProperty("Accept", "text/json");
			conn.setRequestProperty("Authorization", "Basic " + encoding);
			
			//===================================
			
			conn.setDoOutput(true);
			conn.setAllowUserInteraction(false);
			
			PrintStream ps = new PrintStream(conn.getOutputStream());
			ps.print(query);
			ps.close();
			
			//===================================
			
			//if (conn.getResponseCode() != 200) {
			if (conn.getResponseCode() > 250) {
				System.out.println(conn.getResponseCode());
				System.out.println(conn.getResponseMessage());
				
				System.out.println("IOException thrown");
				System.out.println(query);
				
				throw new IOException(conn.getResponseMessage());
			}
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			StringBuilder builder = new StringBuilder();
			String line;
			
			line = reader.readLine();
			while (line != null) {
				builder.append(line);
				line = reader.readLine();
			}
			
			reader.close();
			conn.disconnect();
			
			//Commons.printDocument(builder.toString());
			output = builder.toString();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		return output;
	}
	
	
	
	
	//getAllStories
	/**
	 * returns the output from the request in the form of a String
	 */
	private String requestHelperJSON(String targetURL, String requestMethod) {
		String output = null;
		
		try {
			URL url = new URL(targetURL);
			
			String authString = username + ":" + password;
			String encoding = DatatypeConverter.printBase64Binary(authString.getBytes("UTF-8"));
			
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod(requestMethod);
			conn.setRequestProperty("Content-Type", "text/json");
			conn.setRequestProperty("Accept", "text/json");
			conn.setRequestProperty("Authorization", "Basic " + encoding);
			
			//if (conn.getResponseCode() != 200) {
			if (conn.getResponseCode() > 250) {
				System.out.println(conn.getResponseCode());
				System.out.println(conn.getResponseMessage());
				
				System.out.println("IOException thrown");
				System.out.println(requestMethod + " " + targetURL);
				
				throw new IOException(conn.getResponseMessage());
			}
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			StringBuilder builder = new StringBuilder();
			String line;
			
			line = reader.readLine();
			while (line != null) {
				builder.append(line);
				line = reader.readLine();
			}
			
			reader.close();
			conn.disconnect();
			
			//Commons.printDocument(builder.toString());
			output = builder.toString();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		return output;
	}
}
