package com.cloudscape;

import java.util.LinkedList;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Net.HttpMethods;
import com.badlogic.gdx.Net.HttpRequest;
import com.badlogic.gdx.Net.HttpResponse;
import com.badlogic.gdx.Net.HttpResponseListener;
import com.badlogic.gdx.net.HttpRequestBuilder;
import com.badlogic.gdx.utils.JsonReader;
import com.badlogic.gdx.utils.JsonValue;

public abstract class NetworkRequest {
	
	
	String url;
	
	public NetworkRequest(String url) {
		this.url = url;
	}
	
	public void send() {
		Thread networkRequest = new Thread(new Runnable() {
			@Override
			public void run() {
				HttpRequestBuilder requestBuilder = new HttpRequestBuilder();
				HttpRequest httpRequest = requestBuilder.newRequest().method(HttpMethods.GET).url(url).build();
				Gdx.net.sendHttpRequest(httpRequest, new HttpResponseListener() {
					@Override
					public void cancelled() {
						// TODO Auto-generated method stub
					}
					@Override
					public void failed(Throwable arg0) {
						// TODO Auto-generated method stub
					}
					@Override
					public void handleHttpResponse(HttpResponse response) {
						
						responseHandler(response);
						
					}
				});
			}
		});
		networkRequest.start();
	}
	
	public abstract void responseHandler(HttpResponse response);
	
}
