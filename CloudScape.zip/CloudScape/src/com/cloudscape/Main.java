package com.cloudscape;

import java.util.LinkedList;
import java.util.List;

import com.cloudscape.objects.GameRound;
import com.cloudscape.objects.Grid;
import com.cloudscape.objects.actors.GameActor;
import com.cloudscape.objects.actors.aliens.BeigeAlien;
import com.cloudscape.objects.actors.aliens.BlueAlien;
import com.cloudscape.objects.players.NPC;
import com.cloudscape.objects.players.Player;

public class Main {
	
	//GAME IDEAS: (D&D)
	//the online form of this game will be most like an electronic form of D&D or heroscape
	//allow users to add & rate actors
	//DM (DungeonMaster) starts game and can play instead of the NPC
	//DM can pass off role to new DM
	//you can rate DMs
	//allow users to add/publish and rate maps
	
	//check map saved prior to exit of creator
	//add each level's XML to savedMaps
	//add overwrite prompt if saving to a key that already exists in savedMaps
	
	//automatically select a user's first actor when their turn starts -- Jacob and Conor expected
	//    their first click to be a movement or attack
	//Have a damage number come off of actors after each time they are attacked
	//Conor -- "Skip turn" -- speed/skip past the NPC taking its turn
	//draw full attack range -- like fire emblem -- draw the furthest moveable distance, draw the attack range from there
	//add lots actors, levels, and possibly items
	
	//*** animation
	//sprite sheets
	//more actors and levels
	//add a "weight" for each actor?
	//try watching NPC vs NPC, can help for balancing levels and determining actor weights
	//procedural generation of maps
	//3D maps
	//balance out the levels and actors
	//*** retry GWT since I've figured out packaging of levels??? there was probably more underlying issues than that, though
	
	
	
	//tools.jar stuff?
	//https://www.reddit.com/r/libgdx/comments/2vi8kb/libgdx_gradle_trying_to_use_the_gdxtools_rage_or/
	
	//this dude made gwt work for libgdx
	//https://github.com/saltares/freegemas-gdx
	//try doing it in android studio
	//http://stackoverflow.com/questions/23742328/cant-add-gdx-tools-to-libgdx-gradle-project
	
	//http://www.threerings.net/code/
	
	//gradlew html:dist
	
	//java.home=C:\apps\Java\jre8x64
	
	//http://gaurav.munjal.us/Universal-LPC-Spritesheet-Character-Generator/
	
	//TODO priorities list
	//attack range
	//NPC BFS algorithm
	//add more art resources
	//scale / scrolling
	//chatbox
	//networking
	//different attack styles
	//"clientUsers" for when networking
	
	//a scroll listener for zooming in and out
	//listen for clicks around blocks
	//move more vector logic into screen
	//spawning on game start
	//implement the moveTo() logic
	//NPC BFS algorithm
	//utility for making maps
	//think how game logic will change for users sharing a desktop vs. playing over a network
	//each object that is drawn could implement DrawMe interface, which will have one method that
	//	outputs the lower left edge of the picture, when given a focal point (block) as input
	
	//y inversed issue
	//http://stackoverflow.com/questions/7708379/changing-the-coordinate-system-in-libgdx-java
	
	//networking with libgdx -- use kryonet?
	//http://stackoverflow.com/questions/15179727/connecting-two-devices-using-libgdx
	//https://github.com/EsotericSoftware/kryonet
	//http://gamedev.stackexchange.com/questions/37232/can-networking-be-platform-independent-in-a-libgdx-game
	//http://www.gamefromscratch.com/post/2014/03/11/LibGDX-Tutorial-10-Basic-networking.aspx
	//most RTSs (Real Time Strategy games) use a lock-step system
	//http://gamedev.stackexchange.com/questions/4293/need-help-choosing-the-right-networking-approach-platform-for-an-rts?rq=1
	
	public static void main(String[] args) {
		
		Player michael = new Player("Michael");
		michael.addActor(new BlueAlien(michael));
		
		Player katie = new Player("Katie");
		katie.addActor(new BlueAlien(katie));
		
		Player npc = new NPC();
		npc.addActor(new BlueAlien(npc));
		npc.addActor(new BlueAlien(npc));
		npc.addActor(new BlueAlien(npc));
		
		List<Player> users = new LinkedList<Player>();
		users.add(michael);
		users.add(katie);
		users.add(npc);
		
		//GameRound round = new GameRound(users, "data/exampleMap.xml", true);
		GameRound round = new GameRound(users);
		
		Grid gr = Grid.getInstance();
		System.out.println(gr.getBlockAt(0, 1).getType().toString());
		System.out.println(gr.getBlockAt(0, 2).getType().toString());
		
		//spawning of actors to spawn points should occur here
		//the rest of the following should occur through GUI interaction
		
		//MICHAEL'S TURN
		//System.out.println(round.currentPlayer.toString());
		System.out.println(round.currentPlayer.username);
		//this output is not quite meaningful yet...
		
		michael.getActor(0).moveTo(1, 0);
		//michael.getActor(0).
		
		round.endTurn();
		
		//KATIE'S TURN
		//System.out.println(round.currentPlayer.toString());
		System.out.println(round.currentPlayer.username);
		
		katie.getActor(0).moveTo(2, 0);
		
		round.endTurn();
		
		//NPC'S TURN
		/*
		 * stuff should occur in (possibly) the GameRound class
		 * to check if it is an NPC's turn and handle BFS logic
		 */
		System.out.println(round.currentPlayer.username);
		
		//TODO this must somehow be called at the end of the NPC's algorithm
		round.endTurn();
		
		System.out.println(round.currentPlayer.username);
		
		
		
		
		System.out.println("success");
	}
}
