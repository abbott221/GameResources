package com.cloudscape;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Texture;

public class Commons {
	public static Lock npcLock = new ReentrantLock();
	
	public static String dumpFile(String fileName) {
		FileHandle handle = Gdx.files.internal(fileName);
		String xml = handle.readString();
		return xml;
	}
}
