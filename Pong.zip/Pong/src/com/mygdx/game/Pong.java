package com.mygdx.game;


import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class Pong extends ApplicationAdapter {
	static class Paddle {
		Vector2 position = new Vector2(0,0);
		//Vector2 delta = new Vector2(0,0);
		final static float WIDTH = 6.0f;
		//final static float HEIGHT = 50.0f;
		final static float HEIGHT = 150.0f;
		//final static float SPEED = 64.0f; //pixels per second
		final static float SPEED = 96.0f; //pixels per second
	}
	
	static class Ball {
		Vector2 position = new Vector2(0,0);
		Vector2 velocity = new Vector2(0,0); //pixels per second
		//Vector2 delta = new Vector2(0,0);
		final static float RADIUS = 10.0f;
	}
	
	public static class GameWindow {
		//public final static float WIDTH = 950.0f;
		public final static float WIDTH = 750.0f;
		public final static float HEIGHT = 500.0f;
		
		//public final static float PADDLE_LINE = 800.0f;
		public final static float PADDLE_LINE = 600.0f;
	}
	
	ShapeRenderer shapeBatch;
	
	Paddle paddle;
	Ball ball;
	
	Label score;
	Skin skin;
	Stage stage;
	int scoreCount = 0;
	
	@Override
	public void create () {
		skin = new Skin(Gdx.files.internal("data/uiskin.json"));
		
		stage = new Stage();
		Gdx.input.setInputProcessor(stage);
		
		score = new Label("Score: " + scoreCount, skin);
		score.setPosition(100, 40);
		stage.addActor(score);
		
		shapeBatch = new ShapeRenderer();
		
		paddle = new Paddle();
		paddle.position.set(GameWindow.PADDLE_LINE, 250);
		
		ball = new Ball();
		resetBall();
	}
	
	@Override
	public void render () {
		Gdx.gl.glClearColor(1, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		
		float deltaTime = Gdx.graphics.getDeltaTime();
		
		
		updatePaddle(deltaTime);
		updateBall(deltaTime);
		
		
		shapeBatch.begin(ShapeType.Filled);
		shapeBatch.setColor(Color.BLACK);
		drawPaddle();
		drawBall();
		shapeBatch.end();
		
		score.setText("Score: " + scoreCount);
		
		stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
		stage.draw();
	}
	
	private void resetBall() {
		scoreCount = 0;
		
		ball.position.set(100, GameWindow.HEIGHT / 2.0f);
		//ball.velocity.set(50.0f, 0.0f);
		//ball.velocity.set(80.0f, 0.0f);
		//ball.velocity.set(150.0f, 0.0f);
		//ball.velocity.set(80.0f, 50.0f);
		
		//ball.velocity.set(160.0f, 50.0f);
		ball.velocity.set(220.0f, 50.0f);
	}
	
	private void updatePaddle(float deltaTime) {
		float change = Paddle.SPEED * deltaTime;
		
		if (Gdx.input.isKeyPressed(Keys.UP)) {
			paddle.position.y += change;
		}
		if (Gdx.input.isKeyPressed(Keys.DOWN)) {
			paddle.position.y -= change;
		}
	}
	
	private void updateBall(float deltaTime) {
		//move the ball
		Vector2 change = new Vector2(ball.velocity.x, ball.velocity.y);
		change.scl(deltaTime);
		ball.position.add(change);
		
		//check for collision with paddle
		float ballRight = ball.position.x + Ball.RADIUS;
		if (ballRight > GameWindow.PADDLE_LINE) {
			float paddleBottom = paddle.position.y + (Paddle.HEIGHT / 2.0f);
			float paddleTop = paddle.position.y - (Paddle.HEIGHT / 2.0f);
			
			//collision with paddle does occur
			if (paddleBottom > ball.position.y && ball.position.y > paddleTop) {
				ball.velocity.x = -1.0f * ball.velocity.x;
				scoreCount++;
			}
		}
		
		//check for collision with left wall
		float ballLeft = ball.position.x - Ball.RADIUS;
		if (ballLeft < 0.0f) {
			ball.velocity.x = -1.0f * ball.velocity.x;
		}
		
		float ballBottom = ball.position.y + Ball.RADIUS;
		float ballTop = ball.position.y - Ball.RADIUS;
		
		//check for collision with bottom wall
		if (ballTop < 0.0f) {
			ball.velocity.y = -1.0f * ball.velocity.y;
		}
		
		//check for collision with top wall
		if (ballBottom > GameWindow.HEIGHT) {
			ball.velocity.y = -1.0f * ball.velocity.y;
		}
		
		
		//check if it passed right wall
		if (ballRight > GameWindow.WIDTH) {
			resetBall();
		}
	}
	
	private void drawPaddle() {
		shapeBatch.rect(
				(paddle.position.x - (Paddle.WIDTH / 2.0f)),
				(paddle.position.y - (Paddle.HEIGHT / 2.0f)),
				Paddle.WIDTH,
				Paddle.HEIGHT);
	}
	
	private void drawBall() {
		shapeBatch.circle(ball.position.x, ball.position.y, Ball.RADIUS);
	}
}
